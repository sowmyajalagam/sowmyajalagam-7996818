// Log welcome message to console
console.log("Welcome to the Community Portal");

// Alert when page is fully loaded
window.addEventListener("DOMContentLoaded", function() {
    alert("Page is fully loaded");
});

// Exercise 2: Syntax, Data Types, and Operators
// Event Registration System

// Task 1: Use const for event name and date, let for seats
const eventName = "Tech Conference 2026";
const eventDate = "June 15, 2026";
let availableSeats = 50;

// Get DOM elements
const eventNameSpan = document.getElementById('eventName');
const eventDateSpan = document.getElementById('eventDate');
const seatsCountSpan = document.getElementById('seatsCount');
const registerBtn = document.getElementById('registerBtn');
const resetBtn = document.getElementById('resetBtn');
const messageDiv = document.getElementById('message');

// Task 2: Function to update UI using template literals
function updateEventDisplay() {
    // Using template literals to display event info
    eventNameSpan.textContent = eventName;
    eventDateSpan.textContent = eventDate;
    
    // Update seats display
    seatsCountSpan.textContent = availableSeats;
    seatsCountSpan.style.color = availableSeats < 10 ? '#e74c3c' : '#27ae60';
    
    // Using template literal to create message
    const statusMessage = `Current status for "${eventName}" on ${eventDate}: ${availableSeats} seats remaining`;
    console.log(statusMessage);
}

// Task 3: Function to manage seat count using -- operator
function registerAttendee() {
    if (availableSeats > 0) {
        // Using decrement operator (--)
        availableSeats--;
        
        // Using template literal for success message
        messageDiv.innerHTML = `✅ Registration successful! ${availableSeats} seat${availableSeats !== 1 ? 's' : ''} remaining.`;
        messageDiv.style.backgroundColor = '#d5f4e6';
        
        updateEventDisplay();
        
        // Using template literal with conditional
        if (availableSeats === 0) {
            messageDiv.innerHTML = `🎉 Event "${eventName}" is now SOLD OUT!`;
            registerBtn.disabled = true;
        }
    } else {
        // Using template literal for error message
        messageDiv.innerHTML = `❌ Sorry! "${eventName}" on ${eventDate} is fully booked. No seats available.`;
        messageDiv.style.backgroundColor = '#fadbd8';
    }
}

// Function to reset seats (demonstrates increment operator)
function resetEvent() {
    // Using assignment operator with increment
    availableSeats = 50;
    
    // Using template literal for reset message
    messageDiv.innerHTML = `🔄 Event reset! "${eventName}" now has ${availableSeats} seats available again.`;
    messageDiv.style.backgroundColor = '#f9e79f';
    
    updateEventDisplay();
    registerBtn.disabled = false;
}

// Bonus: Demonstrate increment operator (++)
function demoIncrementOperator() {
    console.log("--- Demonstrating ++ operator ---");
    let testSeats = 5;
    console.log(`Initial seats: ${testSeats}`);
    
    // Using prefix increment
    console.log(`After ++testSeats: ${++testSeats}`); // Shows 6
    
    // Using postfix increment
    console.log(`After testSeats++: ${testSeats++}`); // Shows 6, then becomes 7
    console.log(`Now testSeats is: ${testSeats}`);   // Shows 7
}

// Initialize display
function init() {
    updateEventDisplay();
    
    // Using template literal for initialization message
    console.log(`🎯 Event Registration System initialized for "${eventName}" on ${eventDate}`);
    console.log(`📊 Initial available seats: ${availableSeats}`);
    
    // Demo increment operator (uncomment to see in console)
    // demoIncrementOperator();
}

// Add event listeners
registerBtn.addEventListener('click', registerAttendee);
resetBtn.addEventListener('click', resetEvent);

// Start the application
init();

// Bonus: Show all data types used
console.log("\n--- Data Types Used ---");
console.log(`eventName: ${typeof eventName} (const)`);
console.log(`eventDate: ${typeof eventDate} (const)`);
console.log(`availableSeats: ${typeof availableSeats} (let)`);
console.log(`Template literals: ${typeof `string`} (using backticks)`);
console.log(`Decrement operator (--): applied to availableSeats`);
console.log(`Increment operator (++): demonstrated in demo function`);

// Sample event data
const events = [
  { id: 1, name: "Tech Conference 2026", date: "2026-06-15", seats: 50, registered: 30 },
  { id: 2, name: "Old Workshop", date: "2025-01-10", seats: 20, registered: 20 },
  { id: 3, name: "Future Webinar", date: "2026-07-20", seats: 100, registered: 100 },
  { id: 4, name: "Networking Meetup", date: "2026-06-05", seats: 30, registered: 15 },
  { id: 5, name: "Past Seminar", date: "2025-12-01", seats: 40, registered: 25 }
];

// Get today's date
const today = new Date();

// Task 1 & 2: Use if-else to hide past or full events, and loop using forEach()
console.log("=== Upcoming Events with Available Seats ===\n");

events.forEach(event => {
  const eventDate = new Date(event.date);
  const availableSeats = event.seats - event.registered;
  
  // if-else to check if event is upcoming AND has seats available
  if (eventDate > today && availableSeats > 0) {
    console.log(`✅ ${event.name}`);
    console.log(`   Date: ${event.date}`);
    console.log(`   Available Seats: ${availableSeats}/${event.seats}`);
    console.log(`   ---`);
  } else {
    // Hide past or full events (optional: log why it's hidden)
    if (eventDate <= today) {
      console.log(`❌ ${event.name} - Hidden (Past event)`);
    } else if (availableSeats <= 0) {
      console.log(`❌ ${event.name} - Hidden (No seats available)`);
    }
  }
});

// Task 3: Registration logic wrapped in try-catch
function registerForEvent(eventId, userName) {
  try {
    // Find the event
    const event = events.find(e => e.id === eventId);
    
    // Check if event exists
    if (!event) {
      throw new Error(`Event with ID ${eventId} not found`);
    }
    
    // Check if event is upcoming
    const eventDate = new Date(event.date);
    const today = new Date();
    if (eventDate <= today) {
      throw new Error(`Cannot register: "${event.name}" is a past event`);
    }
    
    // Check if seats are available
    const availableSeats = event.seats - event.registered;
    if (availableSeats <= 0) {
      throw new Error(`Cannot register: "${event.name}" is fully booked`);
    }
    
    // Process registration
    event.registered++;
    console.log(`\n✅ Registration successful!`);
    console.log(`   ${userName} registered for "${event.name}"`);
    console.log(`   Remaining seats: ${event.seats - event.registered}`);
    
    return { success: true, message: `Registered for ${event.name}` };
    
  } catch (error) {
    // Handle any errors
    console.log(`\n❌ Registration failed: ${error.message}`);
    return { success: false, error: error.message };
  }
}

// Example usage of registration with try-catch
console.log("\n=== Testing Registration System ===\n");

// Test successful registration
registerForEvent(1, "Alice Johnson");

// Test registration for full event
registerForEvent(3, "Bob Smith");

// Test registration for non-existent event
registerForEvent(99, "Charlie Brown");

// Test registration for past event
registerForEvent(2, "Diana Prince");
// Event storage
let events = [];

// CLOSURE: Tracks total registrations per category
function createRegistrationTracker() {
    let categoryRegistrations = {};
    
    return {
        increment: (category) => {
            categoryRegistrations[category] = (categoryRegistrations[category] || 0) + 1;
            return categoryRegistrations[category];
        },
        getCount: (category) => categoryRegistrations[category] || 0,
        getAll: () => ({ ...categoryRegistrations })
    };
}

const registrationTracker = createRegistrationTracker();

// FUNCTION 1: Add new event
function addEvent(name, category) {
    if (!name || !category) {
        console.error('Name and category are required');
        return null;
    }
    
    const event = {
        id: Date.now(),
        name: name,
        category: category,
        registrations: 0
    };
    
    events.push(event);
    console.log(`✅ Event "${name}" added to category "${category}"`);
    return event;
}

// FUNCTION 2: Register user for an event
function registerUser(userName, eventId) {
    const event = events.find(e => e.id === eventId);
    
    if (!event) {
        console.error('Event not found');
        return false;
    }
    
    if (!userName) {
        console.error('User name required');
        return false;
    }
    
    event.registrations++;
    const totalInCategory = registrationTracker.increment(event.category);
    
    console.log(`👤 ${userName} registered for "${event.name}"`);
    console.log(`📊 Total registrations in "${event.category}": ${totalInCategory}`);
    
    return { event, totalInCategory };
}

// FUNCTION 3: Filter events with callback (Higher-Order Function)
function filterEventsByCategory(category, customFilter = null) {
    let filteredEvents;
    
    if (customFilter && typeof customFilter === 'function') {
        // Use custom callback for dynamic search
        filteredEvents = events.filter(customFilter);
    } else {
        // Default filter by category
        filteredEvents = events.filter(event => 
            event.category.toLowerCase().includes(category.toLowerCase())
        );
    }
    
    console.log(`\n🔍 Filtered events (${filteredEvents.length} found):`);
    filteredEvents.forEach(event => {
        console.log(`  - ${event.name} (${event.category}) | Registrations: ${event.registrations}`);
    });
    
    return filteredEvents;
}

// Callback examples for dynamic search
function filterByName(searchTerm) {
    return (event) => event.name.toLowerCase().includes(searchTerm.toLowerCase());
}

function filterByMinRegistrations(min) {
    return (event) => event.registrations >= min;
}

function filterByCategory(category) {
    return (event) => event.category === category;
}

// Helper: Display all events
function displayAllEvents() {
    console.log('\n📋 ALL EVENTS:');
    if (events.length === 0) {
        console.log('  No events yet');
        return;
    }
    events.forEach(event => {
        console.log(`  - ${event.name} (${event.category}) | Registrations: ${event.registrations}`);
    });
}

// Helper: Show registration stats (closure demo)
function showRegistrationStats() {
    console.log('\n📊 REGISTRATION STATS (via Closure):');
    const stats = registrationTracker.getAll();
    for (const [category, count] of Object.entries(stats)) {
        console.log(`  ${category}: ${count} total registrations`);
    }
}

// ========== DEMONSTRATION ==========

console.log('=== EVENT MANAGEMENT SYSTEM ===\n');

// Add events
addEvent('Tech Conference 2026', 'Technology');
addEvent('Summer Music Festival', 'Music');
addEvent('AI Workshop', 'Technology');
addEvent('Jazz Night', 'Music');
addEvent('Web Dev Bootcamp', 'Education');

displayAllEvents();

// Register users
console.log('\n=== REGISTRATIONS ===');
registerUser('Alice', events[0].id);  // Tech Conference
registerUser('Bob', events[0].id);     // Tech Conference
registerUser('Charlie', events[1].id); // Music Festival
registerUser('Diana', events[2].id);   // AI Workshop

showRegistrationStats();

// Filter examples with callbacks
console.log('\n=== FILTERING WITH CALLBACKS ===');

// Default filter by category
console.log('\n1. Default filter (Category: Technology):');
filterEventsByCategory('Technology');

// Custom callback: filter by name
console.log('\n2. Custom callback - Filter by name containing "Tech":');
filterEventsByCategory('', filterByName('Tech'));

// Custom callback: filter by minimum registrations
console.log('\n3. Custom callback - Events with 1+ registrations:');
filterEventsByCategory('', filterByMinRegistrations(1));

// Custom callback: exact category match
console.log('\n4. Custom callback - Exact category "Music":');
filterEventsByCategory('', filterByCategory('Music'));

// Final stats
showRegistrationStats();

// Export for module use (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        addEvent,
        registerUser,
        filterEventsByCategory,
        filterByName,
        filterByMinRegistrations,
        filterByCategory,
        getEvents: () => events,
        getStats: () => registrationTracker.getAll()
    };
}
// ========================
// Exercise 5: Objects and Prototypes
// Modeling real-world entities using objects
// ========================

// 1. Define Event constructor function
// Represents a real-world event with properties and methods
function Event(name, type, totalSeats, bookedSeats, location, date) {
    this.name = name;
    this.type = type;           // e.g., "Conference", "Concert", "Workshop"
    this.totalSeats = totalSeats;
    this.bookedSeats = bookedSeats;
    this.location = location;
    this.date = date || new Date().toLocaleDateString();
}

// 2. Add checkAvailability() to prototype
// This method is shared across all Event instances (memory efficient)
Event.prototype.checkAvailability = function() {
    const availableSeats = this.totalSeats - this.bookedSeats;
    return {
        available: availableSeats > 0,
        remainingSeats: availableSeats,
        isFull: availableSeats <= 0,
        message: availableSeats > 0 
            ? `${availableSeats} seat(s) available for "${this.name}"`
            : `Sorry, "${this.name}" is sold out!`
    };
};

// Optional: Add another prototype method for better demonstration
Event.prototype.getOccupancyRate = function() {
    return (this.bookedSeats / this.totalSeats * 100).toFixed(1) + '%';
};

// Helper function to list all enumerable properties using Object.entries()
// This demonstrates the requirement: "List object keys and values using Object.entries()"
function displayEventProperties(eventObj) {
    console.log('\n=== Object.entries() Output ===');
    console.log('Listing all enumerable properties and their values:\n');
    
    // Using Object.entries() to get key-value pairs
    const entries = Object.entries(eventObj);
    
    entries.forEach(([key, value]) => {
        console.log(`  📌 ${key}: ${value}`);
    });
    
    console.log('\n(Note: Prototype methods like checkAvailability() are not shown above');
    console.log('because Object.entries() only lists OWN enumerable properties.)\n');
    
    return entries;
}

// ========================
// DEMONSTRATION & TESTING
// ========================

// Create multiple event instances (real-world entities)
const conferenceEvent = new Event(
    'Tech Summit 2025',
    'Conference',
    500,
    320,
    'San Francisco, CA',
    '2025-03-15'
);

const concertEvent = new Event(
    'Jazz Night Live',
    'Concert',
    200,
    198,
    'Blue Note Jazz Club, NYC',
    '2025-02-28'
);

const workshopEvent = new Event(
    'AI & Machine Learning Workshop',
    'Workshop',
    50,
    50,
    'Online (Zoom)',
    '2025-03-01'
);

const meetupEvent = new Event(
    'Startup Founders Meetup',
    'Networking',
    100,
    45,
    'Austin, TX',
    '2025-02-20'
);

// Store events in an array for iteration
const events = [conferenceEvent, concertEvent, workshopEvent, meetupEvent];

// ========================
// Demonstrate Object.entries() on each event
// ========================
console.log('╔══════════════════════════════════════════════════════════╗');
console.log('║     EXERCISE 5: OBJECTS & PROTOTYPES - DEMONSTRATION     ║');
console.log('╚══════════════════════════════════════════════════════════╝\n');

events.forEach((event, index) => {
    console.log(`\n📅 EVENT #${index + 1}: ${event.name}`);
    console.log('─'.repeat(50));
    
    // Display all own properties using Object.entries()
    displayEventProperties(event);
    
    // Demonstrate prototype method checkAvailability()
    const availability = event.checkAvailability();
    console.log(`🔍 checkAvailability() result:`);
    console.log(`   → ${availability.message}`);
    console.log(`   → Remaining seats: ${availability.remainingSeats}`);
    console.log(`   → Is full: ${availability.isFull}`);
    
    // Demonstrate another prototype method
    console.log(`📊 Occupancy rate: ${event.getOccupancyRate()}`);
});

// ========================
// Additional demonstration: 
// Showing that checkAvailability() is on the prototype, not on each instance
// ========================
console.log('\n' + '═'.repeat(60));
console.log('PROTOTYPE INHERITANCE VERIFICATION');
console.log('═'.repeat(60));

console.log(`\n✓ conferenceEvent.hasOwnProperty('checkAvailability'): ${conferenceEvent.hasOwnProperty('checkAvailability')}`);
console.log(`  (Returns false because method is on the prototype, not the instance itself)`);

console.log(`\n✓ Event.prototype.hasOwnProperty('checkAvailability'): ${Event.prototype.hasOwnProperty('checkAvailability')}`);
console.log(`  (Returns true - the method exists on the prototype chain)`);

console.log(`\n✓ All event instances share the SAME checkAvailability function:`);
console.log(`  conferenceEvent.checkAvailability === workshopEvent.checkAvailability: ${conferenceEvent.checkAvailability === workshopEvent.checkAvailability}`);

// ========================
// Interactive DOM-ready version (if running in browser)
// ========================
if (typeof window !== 'undefined') {
    window.addEventListener('DOMContentLoaded', function() {
        // Create a visual representation in the browser if there's a container
        const container = document.getElementById('exercise-5-demo') || document.body;
        
        const demoDiv = document.createElement('div');
        demoDiv.style.cssText = 'font-family: monospace; background: #f5f5f5; padding: 20px; margin: 20px; border-radius: 8px;';
        demoDiv.innerHTML = '<h2>🎯 Exercise 5: Objects & Prototypes</h2><pre style="background:#fff;padding:15px;overflow-x:auto;">';
        
        let output = '';
        events.forEach((event, index) => {
            output += `\n📌 EVENT ${index + 1}: ${event.name}\n`;
            output += `${'-'.repeat(40)}\n`;
            const entries = Object.entries(event);
            entries.forEach(([key, value]) => {
                output += `  ${key}: ${value}\n`;
            });
            const avail = event.checkAvailability();
            output += `\n  ✓ checkAvailability(): ${avail.message}\n`;
            output += `  ✓ Remaining: ${avail.remainingSeats} seats\n\n`;
        });
        
        demoDiv.querySelector('pre').innerText = output;
        container.appendChild(demoDiv);
    });
}

// Export for Node.js/Module environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { Event, displayEventProperties };
}
// Exercise 6: Arrays and Methods
// Scenario: Manage an array of all community events.
// Objective: Use array methods for CRUD operations.

// ============================================
// 1. Define Event constructor or class
// ============================================
class Event {
    constructor(name, type, location = "TBD") {
        this.name = name;
        this.type = type;        // 'music', 'workshop', 'conference', etc.
        this.location = location;
        this.id = Date.now() + Math.random() * 10000; // unique identifier
    }

    // Instance method for additional functionality
    getSummary() {
        return `${this.name} (${this.type}) at ${this.location}`;
    }
}

// Add checkAvailability() to prototype (Task requirement)
Event.prototype.checkAvailability = function() {
    const availabilityStatus = ['Available', 'Limited Seats', 'Few Left'];
    const randomIdx = Math.floor(Math.random() * 3);
    return `${this.name}: ${availabilityStatus[randomIdx]}`;
};

// ============================================
// 2. Initialize events array
// ============================================
let communityEvents = [];

// ============================================
// 3. Helper Functions for Statistics & Display
// ============================================

// Get total number of events
function getTotalEvents() {
    return communityEvents.length;
}

// Get count of music events using .filter()
function getMusicEventsCount() {
    return communityEvents.filter(event => event.type === 'music').length;
}

// Get all music events using .filter()
function getMusicEvents() {
    return communityEvents.filter(event => event.type === 'music');
}

// ============================================
// 4. CRUD Operations using Array Methods
// ============================================

// CREATE: Add new event using .push()
function addEvent(eventName, eventType, eventLocation) {
    if (!eventName || eventName.trim() === "") {
        console.error("Error: Event name is required");
        return null;
    }
    
    const newEvent = new Event(eventName.trim(), eventType, eventLocation || "TBD");
    communityEvents.push(newEvent);  // Using .push() to add
    console.log(`✅ Added: "${newEvent.name}" using .push()`);
    return newEvent;
}

// READ: Get all events
function getAllEvents() {
    return [...communityEvents];
}

// READ: Get event by ID
function getEventById(id) {
    return communityEvents.find(event => event.id === id);
}

// UPDATE: Update event location using .map() to create new array (immutable approach)
function updateEventLocation(id, newLocation) {
    const eventIndex = communityEvents.findIndex(event => event.id === id);
    if (eventIndex !== -1) {
        communityEvents[eventIndex].location = newLocation;
        console.log(`📍 Updated location for "${communityEvents[eventIndex].name}" to ${newLocation}`);
        return true;
    }
    console.error(`Event with id ${id} not found`);
    return false;
}

// DELETE: Remove event using .filter() (returns new array, reassign)
function deleteEventById(id) {
    const initialLength = communityEvents.length;
    communityEvents = communityEvents.filter(event => event.id !== id);
    
    if (communityEvents.length < initialLength) {
        console.log(`🗑️ Deleted event with id: ${id} using .filter()`);
        return true;
    }
    console.error(`Event with id ${id} not found for deletion`);
    return false;
}

// ============================================
// 5. Display Functions using .map()
// ============================================

// Format display cards using .map() - creates formatted strings like "Workshop on Baking"
function getFormattedEventCards() {
    return communityEvents.map(event => {
        let formattedTitle = "";
        
        // Format based on event type (e.g., "Workshop on Baking" pattern)
        switch (event.type) {
            case 'workshop':
                // Extract base name without "workshop" word for cleaner display
                let cleanName = event.name.replace(/workshop/gi, '').trim();
                formattedTitle = `Workshop on ${cleanName || event.name}`;
                break;
            case 'music':
                formattedTitle = `🎵 Music Event: ${event.name}`;
                break;
            case 'conference':
                formattedTitle = `📢 Conference: ${event.name}`;
                break;
            case 'sports':
                formattedTitle = `⚽ Sports: ${event.name}`;
                break;
            default:
                formattedTitle = `✨ ${event.name}`;
        }
        
        // Return a display card object or formatted string
        return {
            id: event.id,
            displayTitle: formattedTitle,
            type: event.type,
            location: event.location,
            cardHTML: `
                <div class="event-card">
                    <h3>${formattedTitle}</h3>
                    <p>📍 ${event.location}</p>
                    <span class="badge">${event.type}</span>
                </div>
            `
        };
    });
}

// Print formatted cards to console (for demonstration)
function displayFormattedCards() {
    console.log("\n📋 FORMATTED EVENT CARDS (using .map()):");
    const cards = getFormattedEventCards();
    cards.forEach(card => {
        console.log(`   • ${card.displayTitle} - ${card.location}`);
    });
}

// ============================================
// 6. Display Music Events only using .filter()
// ============================================

function displayMusicEvents() {
    console.log("\n🎵 MUSIC EVENTS ONLY (using .filter()):");
    const musicEvents = getMusicEvents();
    
    if (musicEvents.length === 0) {
        console.log("   No music events found.");
        return;
    }
    
    musicEvents.forEach(event => {
        console.log(`   • ${event.name} @ ${event.location}`);
    });
}

// ============================================
// 7. Object.entries() demonstration
// ============================================

function displayEventDetailsAsEntries(event) {
    console.log(`\n📖 Object.entries() for event: "${event.name}"`);
    const entries = Object.entries(event);
    
    entries.forEach(([key, value]) => {
        console.log(`   ${key}: ${value}`);
    });
    
    // Also show prototype method result
    console.log(`   🔔 checkAvailability(): ${event.checkAvailability()}`);
}

// ============================================
// 8. Complete Statistics Report
// ============================================

function showStatistics() {
    console.log("\n📊 COMMUNITY EVENTS STATISTICS");
    console.log("=".repeat(40));
    console.log(`📦 Total events: ${getTotalEvents()}`);
    console.log(`🎵 Music events: ${getMusicEventsCount()}`);
    console.log(`📋 Cards generated (.map): ${communityEvents.length}`);
    console.log("=".repeat(40));
}

// ============================================
// 9. DEMO / Test Execution
// ============================================

function runDemo() {
    console.log("=".repeat(50));
    console.log("🎪 COMMUNITY EVENTS MANAGER - EXERCISE 6");
    console.log("=".repeat(50));
    
    // 1. Add events using .push()
    console.log("\n📌 STEP 1: Adding events using .push()");
    addEvent("Sunset Jazz Night", "music", "City Gardens");
    addEvent("Bread Making Workshop", "workshop", "Community Kitchen");
    addEvent("Electronic Music Festival", "music", "Downtown Arena");
    addEvent("Fullstack Conference 2026", "conference", "Convention Hall");
    addEvent("Acoustic Sundays", "music", "Amphitheater");
    addEvent("Watercolor Painting", "art", "Art Studio");
    
    // Show statistics after additions
    showStatistics();
    
    // 2. Display formatted cards using .map()
    displayFormattedCards();
    
    // 3. Display only music events using .filter()
    displayMusicEvents();
    
    // 4. Demonstrate Object.entries() on a specific event
    const firstEvent = communityEvents[0];
    if (firstEvent) {
        displayEventDetailsAsEntries(firstEvent);
    }
    
    // 5. Demonstrate delete using .filter()
    console.log("\n🗑️ STEP 2: Deleting an event using .filter()");
    const eventToDelete = communityEvents.find(e => e.type === 'art');
    if (eventToDelete) {
        console.log(`   Before deletion: ${getTotalEvents()} events`);
        deleteEventById(eventToDelete.id);
        console.log(`   After deletion: ${getTotalEvents()} events`);
    }
    
    // 6. Final statistics
    showStatistics();
    
    // 7. Demonstrate checkAvailability prototype method
    console.log("\n🔔 STEP 3: Prototype method checkAvailability() demo:");
    communityEvents.forEach(event => {
        console.log(`   ${event.checkAvailability()}`);
    });
    
    console.log("\n✅ Demo complete! Array methods used: .push(), .filter(), .map()");
    console.log("   Also demonstrated: Object.entries() and prototype methods");
}

// ============================================
// 10. Export for use in HTML/other modules
// ============================================

// For Node.js environment
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        Event,
        communityEvents,
        addEvent,
        getAllEvents,
        getMusicEvents,
        getMusicEventsCount,
        getTotalEvents,
        deleteEventById,
        updateEventLocation,
        getFormattedEventCards,
        displayFormattedCards,
        displayMusicEvents,
        showStatistics,
        runDemo
    };
}

// Run demo if executed directly (Node.js)
if (typeof window === 'undefined' && typeof require !== 'undefined') {
    runDemo();
}
// ----------------------------
// DATA MODEL (events array)
// ----------------------------
let events = [
  { id: 1, name: "Sunset Jazz Club", category: "music", registered: false, description: "Live smooth jazz by the waterfront. Unwind with cool rhythms." },
  { id: 2, name: "Baking Masterclass: Sourdough", category: "workshop", registered: false, description: "Hands-on workshop to master artisan bread & pastries." },
  { id: 3, name: "AI & Future Frontiers", category: "tech", registered: false, description: "Explore cutting-edge AI tools and ethics panel." },
  { id: 4, name: "Rock the Park Festival", category: "music", registered: false, description: "Outdoor rock concert with local bands and food trucks." },
  { id: 5, name: "Digital Art Workshop", category: "workshop", registered: false, description: "Learn Procreate and illustration techniques." },
  { id: 6, name: "Cybersecurity Summit", category: "tech", registered: true, description: "Network with experts, zero-day insights & labs." }
];

// Helper to generate sequential IDs for new events
function generateNewId() {
  return events.length > 0 ? Math.max(...events.map(e => e.id)) + 1 : 7;
}

// ----------------------------
// GLOBAL STATE (current filter)
// ----------------------------
let currentFilter = "all";   // "all", "music", "workshop", "tech"

// DOM elements
const eventsContainer = document.getElementById("eventsContainer");
const totalEventSpan = document.getElementById("totalEventCount");
const filterBtns = document.querySelectorAll(".filter-btn");
const addEventBtn = document.getElementById("addEventBtn");
const newEventNameInput = document.getElementById("newEventName");
const newEventCategorySelect = document.getElementById("newEventCategory");

// ----------------------------
// RENDER FUNCTION: uses filter, map, and DOM manipulation
// (shows only music events when filter === 'music' etc.)
// ----------------------------
function renderEvents() {
  // Step 1: filter events based on currentFilter (task requirement: .filter() to show only music events)
  let filteredEvents = events;
  if (currentFilter === "music") {
    filteredEvents = events.filter(event => event.category === "music");
  } else if (currentFilter === "workshop") {
    filteredEvents = events.filter(event => event.category === "workshop");
  } else if (currentFilter === "tech") {
    filteredEvents = events.filter(event => event.category === "tech");
  }

  // Update total event count in header (show total regardless of filter, better UX)
  totalEventSpan.innerText = events.length;

  // Clear container before rendering new cards (classic DOM manipulation)
  while (eventsContainer.firstChild) {
    eventsContainer.removeChild(eventsContainer.firstChild);
  }

  // If no events after filter, show empty message
  if (filteredEvents.length === 0) {
    const emptyDiv = document.createElement("div");
    emptyDiv.className = "empty-message";
    emptyDiv.innerText = "🎭 No events match this category. Add a new one or change filter!";
    eventsContainer.appendChild(emptyDiv);
    return;
  }

  // Use .map() to transform events into formatted display cards (task requirement)
  // We map each filteredEvent to a DOM element using createEventCardElement
  const cardElements = filteredEvents.map(event => {
    return createEventCardElement(event);
  });

  // Append all card elements to container (efficient fragment approach)
  const fragment = document.createDocumentFragment();
  cardElements.forEach(card => fragment.appendChild(card));
  eventsContainer.appendChild(fragment);
}

// Helper: create one event card using DOM manipulation (createElement, setAttribute, classList, textContent)
function createEventCardElement(event) {
  // Main card container
  const card = document.createElement("div");
  card.className = "event-card";
  card.dataset.id = event.id;

  // ------ HEADER section ------
  const headerDiv = document.createElement("div");
  headerDiv.className = "card-header";

  const title = document.createElement("h3");
  title.className = "event-title";
  title.textContent = formatEventTitle(event.name, event.category);

  const categorySpan = document.createElement("span");
  categorySpan.className = "event-category";
  categorySpan.textContent = getCategoryIcon(event.category) + " " + event.category.toUpperCase();

  headerDiv.appendChild(title);
  headerDiv.appendChild(categorySpan);

  // ------ BODY section (description + meta + registered badge) ------
  const bodyDiv = document.createElement("div");
  bodyDiv.className = "card-body";

  const desc = document.createElement("p");
  desc.className = "event-desc";
  desc.textContent = event.description;

  const metaDiv = document.createElement("div");
  metaDiv.className = "event-meta";

  const regStatusSpan = document.createElement("span");
  regStatusSpan.className = "registered-badge";
  regStatusSpan.textContent = event.registered ? "✓ Registered" : "⚡ Not registered";

  metaDiv.appendChild(regStatusSpan);

  bodyDiv.appendChild(desc);
  bodyDiv.appendChild(metaDiv);

  // ------ ACTION buttons (register/cancel) ------
  const actionsDiv = document.createElement("div");
  actionsDiv.className = "card-actions";

  const registerBtn = document.createElement("button");
  registerBtn.textContent = "📌 Register";
  registerBtn.className = "register-btn";
  if (event.registered) {
    registerBtn.disabled = true;
    registerBtn.style.opacity = "0.6";
    registerBtn.title = "Already registered";
  }

  const cancelBtn = document.createElement("button");
  cancelBtn.textContent = "❌ Cancel";
  cancelBtn.className = "cancel-btn";
  if (!event.registered) {
    cancelBtn.disabled = true;
    cancelBtn.style.opacity = "0.5";
    cancelBtn.title = "Not registered yet";
  }

  // Event handling: register click -> update registration status -> re-render UI
  registerBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    if (!event.registered) {
      event.registered = true;
      renderEvents();   // full UI update (reflects registered / cancel states)
    }
  });

  cancelBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    if (event.registered) {
      event.registered = false;
      renderEvents();
    }
  });

  actionsDiv.appendChild(registerBtn);
  actionsDiv.appendChild(cancelBtn);

  card.appendChild(headerDiv);
  card.appendChild(bodyDiv);
  card.appendChild(actionsDiv);
  return card;
}

// helper formatting for event titles (like "Workshop on Baking" style)
function formatEventTitle(rawName, category) {
  // Add creative prefix based on category to simulate mapping display style
  if (category === "workshop") {
    return `🛠️ ${rawName}`;
  } else if (category === "music") {
    return `🎵 ${rawName}`;
  } else if (category === "tech") {
    return `💻 ${rawName}`;
  }
  return rawName;
}

function getCategoryIcon(category) {
  if (category === "music") return "🎵";
  if (category === "workshop") return "🛠️";
  if (category === "tech") return "💻";
  return "📌";
}

// Add new event using .push()
function addNewEvent() {
  const rawName = newEventNameInput.value.trim();
  if (rawName === "") {
    alert("Please enter an event name.");
    return;
  }

  const selectedCategory = newEventCategorySelect.value;
  // Map category to display-friendly description
  let defaultDesc = "";
  if (selectedCategory === "music") defaultDesc = "Exciting music event with incredible artists.";
  else if (selectedCategory === "workshop") defaultDesc = "Interactive workshop to learn new skills.";
  else defaultDesc = "Tech talk about innovation and modern solutions.";

  const newEvent = {
    id: generateNewId(),
    name: rawName,
    category: selectedCategory,
    registered: false,
    description: `${rawName} — ${defaultDesc}`
  };

  // PUSH new event into the events array (fulfills .push() requirement)
  events.push(newEvent);

  // Clear input field
  newEventNameInput.value = "";

  // Re-render UI with updated events (respect current filter)
  renderEvents();
}

// Filter handling + active class
function setActiveFilter(filterValue) {
  currentFilter = filterValue;
  filterBtns.forEach(btn => {
    const btnFilter = btn.getAttribute("data-filter");
    if (btnFilter === filterValue) {
      btn.classList.add("active");
    } else {
      btn.classList.remove("active");
    }
  });
  renderEvents();
}

// Event listeners for filter buttons (using querySelectorAll)
function bindFilterEvents() {
  filterBtns.forEach(btn => {
    btn.addEventListener("click", (e) => {
      const filterType = btn.getAttribute("data-filter");
      setActiveFilter(filterType);
    });
  });
}

// Handle add event button via DOM
function bindAddEvent() {
  addEventBtn.addEventListener("click", () => {
    addNewEvent();
  });
  // allow pressing Enter in input field
  newEventNameInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addNewEvent();
    }
  });
}

// Initialization: render first set, bind events, etc.
function init() {
  bindFilterEvents();
  bindAddEvent();
  renderEvents();
}

// Start the app
init();

/**
 * EXERCISE 8: EVENT HANDLING
 * 
 * Requirements:
 * 1. Use onclick for "Register" buttons
 * 2. Use onchange to filter events by category
 * 3. Use keydown to allow quick search by name
 * 4. Update UI when user registers or cancels
 */

// ============================================
// DATA MODEL
// ============================================

const eventsData = [
    { id: 1, name: "AI Revolution Summit", category: "tech", description: "Explore the future of artificial intelligence and machine learning.", icon: "🤖", registered: false },
    { id: 2, name: "Jazz & Blues Night", category: "music", description: "An evening of smooth jazz and electric blues performances.", icon: "🎷", registered: false },
    { id: 3, name: "UX Design Workshop", category: "workshop", description: "Hands-on workshop learning modern UX design principles.", icon: "🎨", registered: false },
    { id: 4, name: "Mindfulness Meditation", category: "wellness", description: "Guided meditation session for stress relief and clarity.", icon: "🧘", registered: false },
    { id: 5, name: "Cloud Computing Expo", category: "tech", description: "Latest trends in AWS, Azure, and cloud architecture.", icon: "☁️", registered: false },
    { id: 6, name: "Rock Music Festival", category: "music", description: "Live bands, great food, and amazing atmosphere.", icon: "🎸", registered: false },
    { id: 7, name: "Public Speaking Bootcamp", category: "workshop", description: "Master the art of persuasive public speaking.", icon: "🎤", registered: false },
    { id: 8, name: "Yoga Retreat", category: "wellness", description: "Rejuvenate your mind and body with daily yoga sessions.", icon: "🧘‍♀️", registered: false }
];

// ============================================
// APPLICATION STATE
// ============================================

let currentFilter = "all";      // Current category filter value
let currentSearch = "";          // Current search query

// ============================================
// DOM ELEMENT REFERENCES
// (These will be set when DOM is ready)
// ============================================

let eventsGrid;
let categorySelect;
let searchInput;
let resetBtn;
let totalRegisteredSpan;

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Display a temporary toast notification
 */
function showToast(message) {
    // Remove existing toast if present
    const existingToast = document.querySelector(".toast-message");
    if (existingToast) existingToast.remove();
    
    // Create new toast element
    const toast = document.createElement("div");
    toast.className = "toast-message";
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 2rem;
        left: 50%;
        transform: translateX(-50%);
        background: #1e293b;
        color: white;
        padding: 0.75rem 1.5rem;
        border-radius: 50px;
        font-size: 0.875rem;
        font-weight: 500;
        z-index: 1000;
        transition: opacity 0.3s;
        pointer-events: none;
        font-family: system-ui, sans-serif;
    `;
    document.body.appendChild(toast);
    
    // Auto-remove after 2 seconds
    setTimeout(() => {
        toast.style.opacity = "0";
        setTimeout(() => toast.remove(), 300);
    }, 2000);
}

/**
 * Update the total registered count in the UI
 */
function updateTotalRegisteredCount() {
    if (!totalRegisteredSpan) return;
    const count = eventsData.filter(event => event.registered === true).length;
    totalRegisteredSpan.textContent = count;
}

/**
 * Get color for category (for visual styling)
 */
function getCategoryColor(category) {
    const colors = {
        tech: "#3b82f6",
        music: "#8b5cf6",
        workshop: "#f59e0b",
        wellness: "#10b981"
    };
    return colors[category] || "#64748b";
}

/**
 * Get icon for category display
 */
function getCategoryIcon(category) {
    const icons = {
        tech: "💻",
        music: "🎵",
        workshop: "🛠️",
        wellness: "🧘"
    };
    return icons[category] || "📌";
}

/**
 * Escape HTML to prevent XSS attacks
 */
function escapeHtml(text) {
    if (!text) return "";
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// CORE RENDER FUNCTION
// ============================================

/**
 * Render events based on current filter and search criteria
 * This is called whenever:
 * - Category filter changes (onchange)
 * - Search query changes (keydown)
 * - User registers/cancels (onclick)
 */
function renderEvents() {
    if (!eventsGrid) return;
    
    // STEP 1: Filter by category (from onchange handler)
    let filteredEvents = [...eventsData];
    if (currentFilter !== "all") {
        filteredEvents = filteredEvents.filter(event => event.category === currentFilter);
    }
    
    // STEP 2: Filter by search query (from keydown handler)
    if (currentSearch.trim() !== "") {
        const searchLower = currentSearch.trim().toLowerCase();
        filteredEvents = filteredEvents.filter(event => 
            event.name.toLowerCase().includes(searchLower)
        );
    }
    
    // Update the total registered count in the header
    updateTotalRegisteredCount();
    
    // Handle empty state
    if (filteredEvents.length === 0) {
        eventsGrid.innerHTML = `
            <div class="empty-state" style="
                grid-column: 1 / -1;
                text-align: center;
                padding: 4rem;
                background: white;
                border-radius: 1rem;
                color: #64748b;
                font-family: system-ui, sans-serif;
            ">
                😕 No events found matching your criteria.<br>
                Try changing the category or search term.
            </div>
        `;
        return;
    }
    
    // Generate HTML for each event card
    eventsGrid.innerHTML = filteredEvents.map(event => {
        const categoryColor = getCategoryColor(event.category);
        const isRegistered = event.registered;
        const btnText = isRegistered ? "❌ Cancel Registration" : "🎟️ Register";
        const btnClass = isRegistered ? "register-btn cancel" : "register-btn";
        const statusClass = isRegistered ? "registered-status" : "registered-status not";
        const statusText = isRegistered ? "✅ Registered" : "❌ Not Registered";
        
        return `
            <div class="event-card" data-event-id="${event.id}" style="
                background: white;
                border-radius: 1rem;
                overflow: hidden;
                box-shadow: 0 4px 12px rgba(0,0,0,0.08);
                transition: transform 0.2s, box-shadow 0.2s;
            ">
                <div class="event-image" style="
                    height: 140px;
                    position: relative;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: linear-gradient(135deg, ${categoryColor}20, ${categoryColor}40);
                ">
                    <div class="event-icon" style="font-size: 4rem;">${event.icon}</div>
                    <div class="event-category-badge" style="
                        position: absolute;
                        top: 1rem;
                        right: 1rem;
                        background: ${categoryColor};
                        color: white;
                        padding: 0.25rem 0.75rem;
                        border-radius: 50px;
                        font-size: 0.7rem;
                        font-weight: 600;
                    ">${event.category.toUpperCase()}</div>
                </div>
                <div class="event-content" style="padding: 1.25rem;">
                    <h3 class="event-title" style="
                        font-size: 1.25rem;
                        font-weight: 700;
                        color: #0f172a;
                        margin-bottom: 0.5rem;
                    ">${escapeHtml(event.name)}</h3>
                    <span class="event-category" style="
                        display: inline-block;
                        background: #dbeafe;
                        color: #1e40af;
                        padding: 0.2rem 0.7rem;
                        border-radius: 50px;
                        font-size: 0.7rem;
                        font-weight: 600;
                        margin-bottom: 0.75rem;
                    ">${getCategoryIcon(event.category)} ${event.category.charAt(0).toUpperCase() + event.category.slice(1)}</span>
                    <p class="event-description" style="
                        color: #475569;
                        font-size: 0.875rem;
                        line-height: 1.5;
                        margin-bottom: 1rem;
                    ">${escapeHtml(event.description)}</p>
                    <div class="event-actions" style="
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        border-top: 1px solid #e2e8f0;
                        padding-top: 1rem;
                    ">
                        <button class="${btnClass}" data-id="${event.id}" style="
                            background: ${isRegistered ? '#ef4444' : '#3b82f6'};
                            color: white;
                            border: none;
                            padding: 0.5rem 1.25rem;
                            border-radius: 0.5rem;
                            font-weight: 600;
                            font-size: 0.875rem;
                            cursor: pointer;
                            transition: background 0.2s;
                        ">${btnText}</button>
                        <span class="${statusClass}" style="
                            font-size: 0.75rem;
                            font-weight: 600;
                            padding: 0.25rem 0.75rem;
                            border-radius: 50px;
                            background: ${isRegistered ? '#dcfce7' : '#f1f5f9'};
                            color: ${isRegistered ? '#166534' : '#64748b'};
                        ">${statusText}</span>
                    </div>
                </div>
            </div>
        `;
    }).join("");
    
    // ============================================
    // REQUIREMENT 1: Use onclick for "Register" buttons
    // Attach click handlers to all register/cancel buttons
    // ============================================
    document.querySelectorAll(".register-btn").forEach(button => {
        button.onclick = function(e) {
            e.stopPropagation();
            const eventId = parseInt(this.getAttribute("data-id"));
            handleRegistration(eventId);
        };
    });
}

// ============================================
// REGISTRATION HANDLER
// ============================================

/**
 * Handle registration or cancellation for an event
 * Toggles the registered status and updates UI
 */
function handleRegistration(eventId) {
    const event = eventsData.find(e => e.id === eventId);
    if (!event) return;
    
    const wasRegistered = event.registered;
    event.registered = !wasRegistered;
    
    const action = event.registered ? "registered for" : "canceled registration for";
    showToast(`✨ You ${action} "${event.name}"`);
    
    // Re-render to update UI
    renderEvents();
}

// ============================================
// FILTER HANDLERS
// ============================================

/**
 * Handle category filter change
 * REQUIREMENT 2: Use onchange to filter events by category
 */
function handleCategoryChange() {
    if (!categorySelect) return;
    currentFilter = categorySelect.value;
    renderEvents();
    showToast(`📂 Showing: ${currentFilter === "all" ? "all categories" : currentFilter + " events"}`);
}

/**
 * Handle search input via keydown event
 * REQUIREMENT 3: Use keydown to allow quick search by name
 */
function handleSearchKeydown(event) {
    // Using setTimeout to ensure we capture the latest input value after the keypress
    setTimeout(() => {
        if (searchInput) {
            currentSearch = searchInput.value;
            renderEvents();
        }
    }, 0);
}

/**
 * Optional: Handle search input for real-time updates (enhances UX)
 */
function handleSearchInput() {
    if (searchInput) {
        currentSearch = searchInput.value;
        renderEvents();
    }
}

/**
 * Reset all filters to default state
 */
function resetFilters() {
    if (categorySelect) categorySelect.value = "all";
    if (searchInput) searchInput.value = "";
    currentFilter = "all";
    currentSearch = "";
    renderEvents();
    showToast("🔄 Filters reset - showing all events");
}

// ============================================
// INITIALIZATION
// ============================================

/**
 * Initialize the application:
 * - Get DOM element references
 * - Set up event listeners (onchange, keydown, onclick for reset)
 * - Render initial events
 */
function initEventHandling() {
    // Get DOM element references
    eventsGrid = document.getElementById("eventsGrid");
    categorySelect = document.getElementById("categorySelect");
    searchInput = document.getElementById("searchInput");
    resetBtn = document.getElementById("resetBtn");
    totalRegisteredSpan = document.getElementById("totalRegistered");
    
    // Validate required elements exist
    if (!eventsGrid) {
        console.error("Required DOM element 'eventsGrid' not found");
        return;
    }
    
    // ============================================
    // REQUIREMENT 2: Set up onchange event for category filter
    // ============================================
    if (categorySelect) {
        categorySelect.onchange = handleCategoryChange;
    }
    
    // ============================================
    // REQUIREMENT 3: Set up keydown event for quick search
    // ============================================
    if (searchInput) {
        searchInput.onkeydown = handleSearchKeydown;
        // Optional: also support input event for better UX
        searchInput.oninput = handleSearchInput;
    }
    
    // Set up reset button click
    if (resetBtn) {
        resetBtn.onclick = resetFilters;
    }
    
    // Initial render of events
    renderEvents();
    
    // Welcome message
    showToast("🎉 Welcome! Use search (keydown), filter (onchange), or click Register buttons!");
}

// Start the application when DOM is ready
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initEventHandling);
} else {
    initEventHandling();
}

// ============================================
// EXPORTS (for module systems if needed)
// ============================================

if (typeof module !== "undefined" && module.exports) {
    module.exports = {
        eventsData,
        renderEvents,
        handleRegistration,
        handleCategoryChange,
        handleSearchKeydown,
        resetFilters,
        currentFilter,
        currentSearch
    };
}

// ----------------------------------------------
// MOCK API ENDPOINT (simulates remote JSON API)
// Returns Promise with 20% random error rate to demonstrate error handling
// ----------------------------------------------

function mockFetchAPI() {
    return new Promise((resolve, reject) => {
        // Simulate network latency (700-1100ms)
        const delay = 700 + Math.random() * 400;
        // 20% chance to simulate a server error (demonstrates error handling)
        const shouldFail = Math.random() < 0.2;
        
        setTimeout(() => {
            if (shouldFail) {
                reject(new Error("⚠️ Mock API error: Failed to fetch events (server responded with 500). Please retry."));
                return;
            }
            
            // Generate realistic event dataset
            const events = [
                { id: 1, title: "🎤 Frontend Summit 2026", date: "June 12, 2026", description: "Deep dive into modern async patterns, React 19 and signals.", category: "Conference" },
                { id: 2, title: "💻 Async JavaScript Workshop", date: "June 18, 2026", description: "Master Promises, async/await, and error handling in real apps.", category: "Workshop" },
                { id: 3, title: "🌐 Web Performance Meetup", date: "June 25, 2026", description: "Optimize loading strategies, code splitting and resource hints.", category: "Meetup" },
                { id: 4, title: "🤖 AI & JS Hackathon", date: "July 02, 2026", description: "Build intelligent apps using LLMs and JavaScript. Team up!", category: "Hackathon" },
                { id: 5, title: "⚛️ State Management Deep Dive", date: "July 10, 2026", description: "Explore Zustand, Redux Toolkit, and Jotai with async actions.", category: "Talk" }
            ];
            
            // Build mock Response object (compatible with standard fetch)
            const responseBody = { success: true, events: events, timestamp: new Date().toISOString() };
            const mockResponse = {
                ok: true,
                status: 200,
                json: async () => responseBody,
                text: async () => JSON.stringify(responseBody)
            };
            resolve(mockResponse);
        }, delay);
    });
}

// Helper function that fetches and returns parsed events array
async function fetchEventsFromMock() {
    const response = await mockFetchAPI();   // throws on error
    const data = await response.json();
    if (!data.events || !Array.isArray(data.events)) {
        throw new Error("Invalid data format from API");
    }
    return data.events;
}


// ----------------------------------------------
// DOM ELEMENTS & RENDER HELPERS
// ----------------------------------------------

const contentArea = document.getElementById('contentArea');
const promiseBtn = document.getElementById('promiseBtn');
const asyncBtn = document.getElementById('asyncBtn');
const clearBtn = document.getElementById('clearBtn');

// Render events list into the UI
function renderEvents(eventsArray) {
    if (!eventsArray || eventsArray.length === 0) {
        contentArea.innerHTML = `
            <div class="info-message">
                📭 No events available. Try fetching again.
            </div>
        `;
        return;
    }
    
    const eventsHtml = `
        <div class="events-container">
            <div style="margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: baseline; flex-wrap:wrap;">
                <h3 style="margin:0; font-size:1.2rem;">📌 Upcoming Events (${eventsArray.length})</h3>
                <span class="badge">live mock data</span>
            </div>
            <div class="event-list">
                ${eventsArray.map(event => `
                    <div class="event-item">
                        <div class="event-title">${escapeHtml(event.title)}</div>
                        <div class="event-date">
                            📅 ${escapeHtml(event.date)}
                            <span class="badge">${escapeHtml(event.category || 'Event')}</span>
                        </div>
                        <div class="event-desc">${escapeHtml(event.description || 'No description provided.')}</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    contentArea.innerHTML = eventsHtml;
}

// Display error message
function renderError(errorMsg) {
    contentArea.innerHTML = `
        <div class="events-container">
            <div class="error-message">
                ❌ <strong>Error</strong><br>${escapeHtml(errorMsg)}
            </div>
            <div class="info-message" style="margin-top: 1rem;">
                💡 Tip: Click again — random failures demonstrate real-world resilience.
            </div>
        </div>
    `;
}

// Show loading spinner (used by async/await version)
function showLoadingSpinner() {
    contentArea.innerHTML = `
        <div class="spinner-container">
            <div class="loader"></div>
            <div style="margin-left: 12px; color: #2c3e66;">Fetching latest events ...</div>
        </div>
    `;
}

// XSS prevention helper
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}


// ----------------------------------------------
// 1. PROMISE CHAIN METHOD (.then() / .catch())
// ----------------------------------------------

function fetchWithPromiseChain() {
    // Show loading status
    contentArea.innerHTML = `<div class="info-message">⏳ Fetching events using .then() chain ... Please wait.</div>`;
    
    fetchEventsFromMock()
        .then(events => {
            renderEvents(events);
            console.log("[Promise .then] events fetched:", events.length);
        })
        .catch(err => {
            console.warn("[Promise .catch] Error:", err);
            let errorText = err.message || "Unknown error occurred while fetching events.";
            renderError(`Promise error: ${errorText}`);
        });
}


// ----------------------------------------------
// 2. ASYNC/AWAIT METHOD (with loading spinner)
// ----------------------------------------------

async function fetchWithAsyncAwait() {
    // Show loading spinner as required by exercise
    showLoadingSpinner();
    
    try {
        const events = await fetchEventsFromMock();
        renderEvents(events);
    } catch (error) {
        console.error("[async/await] caught error:", error);
        let errorMsg = error.message || "Async/Await fetch failed due to network or mock error.";
        renderError(`Async/Await error: ${errorMsg}`);
    }
}


// ----------------------------------------------
// 3. CLEAR EVENTS FUNCTION
// ----------------------------------------------

function clearEvents() {
    contentArea.innerHTML = `
        <div class="info-message">
            ✨ Events cleared. Click a fetch button to load events from mock API.<br>
            <span style="font-size:0.8rem">Promise style handles errors via .catch &nbsp;|&nbsp; Async/await shows loading spinner + try/catch</span>
        </div>
    `;
}


// ----------------------------------------------
// EVENT LISTENERS & INITIALIZATION
// ----------------------------------------------

promiseBtn.addEventListener('click', () => {
    fetchWithPromiseChain();
});

asyncBtn.addEventListener('click', () => {
    fetchWithAsyncAwait();
});

clearBtn.addEventListener('click', () => {
    clearEvents();
});

// Initialize with clear state
clearEvents();
/**
 * Modern JavaScript Features (ES6+) - Core Refactoring Module
 * 
 * Objective: Use let/const, default parameters, destructuring, spread operator.
 * Context: Event management system - filter events without mutating original data.
 * 
 * This file demonstrates clean, maintainable ES6+ patterns as required.
 */

// ------------------------------
// 1. CONST & LET (no var)
// ------------------------------
const ORIGINAL_EVENTS = [
  { id: 1, name: "Frontend Summit", date: "2025-06-10", category: "conference", venue: "Convention Hall" },
  { id: 2, name: "Node.js Workshop", date: "2025-06-15", category: "workshop", venue: "Tech Hub" },
  { id: 3, name: "AI & ML Symposium", date: "2025-06-20", category: "conference", venue: "Innovation Center" },
  { id: 4, name: "React Deep Dive", date: "2025-06-25", category: "workshop", venue: "Online" },
  { id: 5, name: "Design Systems Meetup", date: "2025-07-01", category: "meetup", venue: "Design Studio" },
  { id: 6, name: "Security in JS", date: "2025-07-05", category: "workshop", venue: "Cyber Dome" }
];

// mutable state but controlled: we use let only where reassignment is needed
let currentFilter = "all";       // possible values: 'all', 'workshop', 'conference'
let filteredEvents = [...ORIGINAL_EVENTS];   // starts as a clone (spread operator)

// ------------------------------
// 2. DEFAULT PARAMETERS IN FUNCTIONS
// ------------------------------
/**
 * Filters events based on type (uses default parameter "all")
 * IMPORTANT: Clones the input array using spread operator BEFORE filtering
 * to avoid mutation of the original array (immutability pattern).
 * 
 * @param {Array} events - list of event objects
 * @param {string} type - filter type: "all", "workshop", "conference" (default = "all")
 * @returns {Array} new filtered array (cloned)
 */
const filterEvents = (events, type = "all") => {
  // 3. SPREAD OPERATOR: clone event list before any filtering
  const clonedEvents = [...events];
  
  if (type === "workshop") {
    // 4. DESTRUCTURING inside filter callback: extract 'category' directly
    return clonedEvents.filter(({ category }) => category === "workshop");
  }
  
  if (type === "conference") {
    return clonedEvents.filter(({ category }) => category === "conference");
  }
  
  // return the cloned array for "all" (still a copy, no mutation)
  return clonedEvents;
};

// ------------------------------
// 3. DESTRUCTURING (function parameter & variable)
// ------------------------------
/**
 * Creates a formatted summary for an event.
 * Uses destructuring in the parameter to extract event properties.
 * Also uses default parameter for the greeting.
 * 
 * @param {Object} event - event object
 * @param {string} greeting - optional custom greeting (default provided)
 * @returns {string} formatted event summary
 */
const buildEventSummary = (event, greeting = "📢 Event Spotlight") => {
  // Destructuring assignment: extract multiple properties at once
  const { name, date, category, venue } = event;
  
  // Template literal for clean string interpolation
  return `${greeting} 🎉 "${name}" on ${date} | ${category} @ ${venue}`;
};

/**
 * Advanced destructuring demo: nested destructuring + default values.
 * Shows how to extract event details safely.
 */
const getEventDetails = ({ name = "TBD", date = "Future", category = "general", venue = "virtual" } = {}) => {
  // Destructuring already happened in parameter!
  return { eventName: name, eventDate: date, eventCategory: category, location: venue };
};

// ------------------------------
// 4. SPREAD OPERATOR (additional use cases)
// ------------------------------
/**
 * Merges new events with existing ones (immutable merge)
 * Demonstrates spread for array concatenation.
 */
const addNewEvents = (existingEvents, newEventsArray) => {
  // spread both arrays into a new one -> no mutation
  return [...existingEvents, ...newEventsArray];
};

/**
 * Clones an event and updates a property (immutable update)
 * Uses spread operator on object as well.
 */
const updateEventProperty = (event, newName) => {
  // object spread: create shallow copy then override name
  return { ...event, name: newName };
};

// ------------------------------
// 5. PRACTICAL DEMO FUNCTIONS (tying everything together)
// ------------------------------
/**
 * Main function that updates the filtered list based on current filter type.
 * Demonstrates closure and usage of our ES6+ filterEvents.
 */
const updateFilteredEvents = () => {
  // using default parameter implicitly (filterEvents has default "all")
  filteredEvents = filterEvents(ORIGINAL_EVENTS, currentFilter);
  return filteredEvents;
};

/**
 * Changes the active filter and returns new filtered list (immutable chain)
 * @param {string} newFilter - "all", "workshop", or "conference"
 */
const setFilter = (newFilter) => {
  currentFilter = newFilter;
  return updateFilteredEvents();
};

/**
 * Resets to original events using spread to demonstrate fresh clone.
 */
const resetEvents = () => {
  currentFilter = "all";
  filteredEvents = [...ORIGINAL_EVENTS];  // spread clone
  return filteredEvents;
};

// ------------------------------
// 6. RENDER HELPER (using destructuring inside loop)
// ------------------------------
/**
 * Renders events to a container (just for demonstration — returns HTML string)
 * Showcases destructuring in a loop + map + template literals.
 */
const renderEventList = (events) => {
  if (!events.length) {
    return "<div>✨ No events match the filter.</div>";
  }
  
  // Destructuring directly in map callback parameter
  const htmlString = events.map(({ id, name, date, category }) => {
    // dynamic badge logic (just for visual differentiation)
    const badgeColor = category === "workshop" ? "#facc15" : (category === "conference" ? "#3b82f6" : "#94a3b8");
    return `
      <div style="border-left: 4px solid ${badgeColor}; padding: 0.5rem; margin-bottom: 0.5rem; background: white; border-radius: 12px;">
        <strong>${escapeHtml(name)}</strong> <span style="font-size:0.7rem;">(id: ${id})</span><br>
        📅 ${date} · ${category}
      </div>
    `;
  }).join('');
  
  return `<div class="event-list-modern">${htmlString}</div>`;
};

// simple XSS protection helper
const escapeHtml = (str) => {
  return str.replace(/[&<>]/g, (m) => {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
};

// ------------------------------
// 7. ADVANCED: Demo of destructuring + default params in one-line arrow
// ------------------------------
const getWorkshopNames = (events = ORIGINAL_EVENTS) => {
  // pipeline: filter using destructuring, then map to names
  return events
    .filter(({ category }) => category === "workshop")
    .map(({ name }) => name);
};

// Example of using default parameters with object destructuring (complex but robust)
const registerAttendee = ({ name = "Guest", eventId = 0, email = "no-reply@example.com" } = {}) => {
  return `✅ ${name} (${email}) registered for event #${eventId}`;
};

// ------------------------------
// 8. EXPORTS (if using modules) + console demo for verification
// ------------------------------
// For Node.js environment or modern bundlers, you can export:
// export { 
//   ORIGINAL_EVENTS, filterEvents, buildEventSummary, getEventDetails,
//   addNewEvents, updateEventProperty, setFilter, resetEvents, 
//   renderEventList, getWorkshopNames, registerAttendee
// };

// ------------------------------
// SELF-CONTAINED DEMO (run this to see ES6+ in action)
// ------------------------------
const runDemo = () => {
  console.log("===== Modern JavaScript Features Demo =====");
  console.log("1. Const & Let: ORIGINAL_EVENTS (const), currentFilter (let) => no var pollution.");
  
  // default parameters demo
  console.log("\n2. Default Parameters:");
  console.log("   filterEvents with only events argument (type defaults to 'all'):", 
              filterEvents(ORIGINAL_EVENTS).length, "events (cloned)");
  console.log("   filterEvents with explicit 'workshop':", 
              filterEvents(ORIGINAL_EVENTS, "workshop").length, "workshops");
  
  // destructuring demo
  console.log("\n3. Destructuring + Default Params:");
  const firstEvent = ORIGINAL_EVENTS[0];
  console.log("   buildEventSummary:", buildEventSummary(firstEvent));
  console.log("   buildEventSummary with custom greeting:", buildEventSummary(firstEvent, "🔥 EXCLUSIVE"));
  console.log("   getEventDetails (destructuring in param):", getEventDetails(firstEvent));
  
  // spread operator clone proof
  console.log("\n4. Spread Operator (Clone before filtering):");
  const originalLength = ORIGINAL_EVENTS.length;
  const workshopEvents = filterEvents(ORIGINAL_EVENTS, "workshop");
  console.log(`   Original array unchanged? ${ORIGINAL_EVENTS.length === originalLength ? "YES (immutable)" : "NO"}`);
  console.log(`   Filtered workshops: ${workshopEvents.length} (cloned subset)`);
  
  // More spread: merging arrays
  const newEvent = { id: 7, name: "AI Hackathon", date: "2025-07-20", category: "workshop", venue: "Tech Campus" };
  const extendedList = addNewEvents(ORIGINAL_EVENTS, [newEvent]);
  console.log("   Spread merge (addNewEvents): original stays", ORIGINAL_EVENTS.length, "extended becomes", extendedList.length);
  
  // setFilter & reset
  console.log("\n5. Practical filter state management:");
  setFilter("workshop");
  console.log(`   After setFilter('workshop'): ${filteredEvents.length} workshops shown`);
  resetEvents();
  console.log(`   After resetEvents: ${filteredEvents.length} events (original cloned again)`);
  
  // helper functions
  console.log("\n6. Helper: getWorkshopNames (destructuring + functional chaining)");
  console.log("   Workshop names:", getWorkshopNames());
  
  console.log("\n7. Register attendee with default params & destructuring:");
  console.log("   ", registerAttendee({ name: "Alice", eventId: 42, email: "alice@dev.com" }));
  console.log("   ", registerAttendee()); // uses all defaults
  
  console.log("\n✅ All ES6+ features demonstrated: let/const, default parameters, destructuring, spread operator, arrow functions, template literals.");
};

// Uncomment the line below to run the demo in Node.js or browser console:
runDemo();

// For browser global exposure (optional)
if (typeof window !== 'undefined') {
  window.es6Demo = {
    filterEvents,
    buildEventSummary,
    setFilter,
    resetEvents,
    renderEventList,
    getWorkshopNames,
    registerAttendee,
    ORIGINAL_EVENTS
  };
  console.log("ES6+ module loaded. Access via window.es6Demo");
}
/**
 * Exercise 11: Working with Forms - Event Registration Form
 * 
 * Requirements:
 * - Capture name, email, and selected event using form.elements
 * - Prevent default form behavior using event.preventDefault()
 * - Validate inputs and show errors inline
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
  
  // Get the form element
  const registrationForm = document.getElementById('registrationForm');
  
  // Get error container elements
  const errorContainers = {
    name: document.getElementById('nameError'),
    email: document.getElementById('emailError'),
    event: document.getElementById('eventError')
  };
  
  // Get status display element
  const statusDiv = document.getElementById('liveStatus');
  
  /**
   * Helper: Display error message for a specific field
   * @param {string} field - Field name ('name', 'email', or 'event')
   * @param {string} message - Error message to display (empty string clears error)
   */
  function setFieldError(field, message) {
    const container = errorContainers[field];
    if (container) {
      if (message) {
        container.innerHTML = `<div class="error-message inline-error">⚠️ ${escapeHtml(message)}</div>`;
      } else {
        container.innerHTML = '';
      }
    }
  }
  
  /**
   * Clear all inline error messages
   */
  function clearAllFieldErrors() {
    setFieldError('name', '');
    setFieldError('email', '');
    setFieldError('event', '');
  }
  
  /**
   * Simple XSS prevention helper
   * @param {string} str - String to escape
   * @returns {string} - Escaped string
   */
  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
      if (m === '&') return '&amp;';
      if (m === '<') return '&lt;';
      if (m === '>') return '&gt;';
      return m;
    });
  }
  
  /**
   * Validate registration form inputs
   * @param {string} name - Full name value
   * @param {string} email - Email address value
   * @param {string} eventValue - Selected event value
   * @returns {Object} - { isValid: boolean, errors: object }
   */
  function validateRegistration(name, email, eventValue) {
    let errors = { name: '', email: '', event: '' };
    let isValid = true;
    
    // Name validation
    const nameClean = name.trim();
    if (!nameClean) {
      errors.name = 'Full name is required.';
      isValid = false;
    } else if (nameClean.length < 2) {
      errors.name = 'Name must be at least 2 characters long.';
      isValid = false;
    } else if (!/^[A-Za-zÀ-ÿ\s\-'.]+$/.test(nameClean)) {
      errors.name = 'Use letters, spaces, hyphens or apostrophes only.';
      isValid = false;
    }
    
    // Email validation
    const emailClean = email.trim();
    if (!emailClean) {
      errors.email = 'Email address is required.';
      isValid = false;
    } else {
      const emailRegex = /^[^\s@]+@([^\s@.,]+\.)+[^\s@.,]{2,}$/;
      if (!emailRegex.test(emailClean)) {
        errors.email = 'Please enter a valid email (e.g., name@domain.com).';
        isValid = false;
      }
    }
    
    // Event validation
    if (!eventValue || eventValue === "") {
      errors.event = 'Please select an event from the dropdown.';
      isValid = false;
    }
    
    return { isValid, errors };
  }
  
  /**
   * Display inline errors for each field
   * @param {Object} errors - Errors object containing messages for each field
   */
  function displayInlineErrors(errors) {
    setFieldError('name', errors.name);
    setFieldError('email', errors.email);
    setFieldError('event', errors.event);
  }
  
  /**
   * Update the status panel message
   * @param {string} message - Message to display
   * @param {boolean} isError - Whether this is an error message
   * @param {boolean} isSuccess - Whether this is a success message
   */
  function setStatusMessage(message, isError = false, isSuccess = false) {
    statusDiv.innerHTML = message;
    statusDiv.classList.remove('success', 'error-summary');
    if (isSuccess) {
      statusDiv.classList.add('success');
    } else if (isError) {
      statusDiv.classList.add('error-summary');
    }
  }
  
  /**
   * MAIN SUBMIT HANDLER
   * Demonstrates:
   * 1. Using form.elements to capture form data
   * 2. event.preventDefault() to prevent default form submission
   * 3. Validation with inline error display
   */
  function handleFormSubmit(event) {
    // REQUIREMENT 2: Prevent default form behavior
    event.preventDefault();
    
    // REQUIREMENT 1: Capture name, email, and selected event using form.elements
    const elementsCollection = registrationForm.elements;
    const nameField = elementsCollection.namedItem('fullname');
    const emailField = elementsCollection.namedItem('email');
    const eventField = elementsCollection.namedItem('event');
    
    // Extract values from the captured elements
    const nameValue = nameField ? nameField.value : '';
    const emailValue = emailField ? emailField.value : '';
    const eventValue = eventField ? eventField.value : '';
    
    // Trim whitespace from name and email for validation
    const trimmedName = nameValue.trim();
    const trimmedEmail = emailValue.trim();
    const selectedEvent = eventValue;
    
    // REQUIREMENT 3: Validate inputs
    const validation = validateRegistration(trimmedName, trimmedEmail, selectedEvent);
    
    // Clear previous inline errors
    clearAllFieldErrors();
    
    if (validation.isValid) {
      // SUCCESS: All inputs are valid
      const successMessage = `✅ Registration successful! Welcome ${escapeHtml(trimmedName)}. You're registered for "${escapeHtml(selectedEvent)}". Confirmation sent to ${escapeHtml(trimmedEmail)}.`;
      setStatusMessage(successMessage, false, true);
      console.log('Registration successful:', { 
        name: trimmedName, 
        email: trimmedEmail, 
        event: selectedEvent 
      });
    } else {
      // FAILURE: Display inline errors
      displayInlineErrors(validation.errors);
      
      // Build error summary message
      const errorList = [];
      if (validation.errors.name) errorList.push(`• Name: ${validation.errors.name}`);
      if (validation.errors.email) errorList.push(`• Email: ${validation.errors.email}`);
      if (validation.errors.event) errorList.push(`• Event: ${validation.errors.event}`);
      
      const summaryHtml = `❌ Please fix the following errors:<br>${errorList.join('<br>')}`;
      setStatusMessage(summaryHtml, true, false);
    }
  }
  
  /**
   * Reset the form - clears all fields and errors
   */
  function resetForm() {
    // Use form.elements to access and clear form fields
    const elements = registrationForm.elements;
    const nameInput = elements.namedItem('fullname');
    const emailInput = elements.namedItem('email');
    const eventSelect = elements.namedItem('event');
    
    if (nameInput) nameInput.value = '';
    if (emailInput) emailInput.value = '';
    if (eventSelect) eventSelect.value = '';
    
    // Clear all inline errors
    clearAllFieldErrors();
    
    // Reset status message
    setStatusMessage('✨ Form has been reset. Fill in your details and submit.', false, false);
    statusDiv.classList.remove('success', 'error-summary');
  }
  
  /**
   * Attach live error clearing - improves UX by removing field-specific errors
   * as the user types (not required but demonstrates thoughtful implementation)
   */
  function attachLiveClearErrors() {
    const nameElem = registrationForm.elements.namedItem('fullname');
    const emailElem = registrationForm.elements.namedItem('email');
    const eventElem = registrationForm.elements.namedItem('event');
    
    if (nameElem) {
      nameElem.addEventListener('input', function() {
        setFieldError('name', '');
      });
    }
    if (emailElem) {
      emailElem.addEventListener('input', function() {
        setFieldError('email', '');
      });
    }
    if (eventElem) {
      eventElem.addEventListener('change', function() {
        setFieldError('event', '');
      });
    }
  }
  
  // ========== EVENT LISTENERS ==========
  
  // Attach submit handler with preventDefault behavior
  registrationForm.addEventListener('submit', handleFormSubmit);
  
  // Attach reset button handler
  const resetBtn = document.getElementById('resetBtn');
  if (resetBtn) {
    resetBtn.addEventListener('click', resetForm);
  }
  
  // Attach live error clearing for better UX
  attachLiveClearErrors();
  
  // Initialize form state
  clearAllFieldErrors();
  setStatusMessage('📝 Please complete the registration form. All fields are required.', false, false);
});

/**
 * Exercise 12: AJAX & Fetch API - User Registration Simulation
 * 
 * This module handles:
 * - Form validation with inline error display
 * - Preventing default form behavior
 * - POST request using fetch() to a mock API
 * - Success/failure messaging after submission
 * - setTimeout() to simulate delayed response
 */

// Wait for DOM to be fully loaded before attaching event listeners
document.addEventListener('DOMContentLoaded', function() {
  
  // ======================== DOM Element References ========================
  const form = document.getElementById('registrationForm');
  const nameInput = document.getElementById('fullname');
  const emailInput = document.getElementById('email');
  const eventSelect = document.getElementById('eventSelect');
  const nameErrorDiv = document.getElementById('nameError');
  const emailErrorDiv = document.getElementById('emailError');
  const eventErrorDiv = document.getElementById('eventError');
  const liveStatusMsg = document.getElementById('liveStatusMsg');
  const submitBtn = document.getElementById('submitBtn');
  const resetBtn = document.getElementById('resetBtn');

  // ======================== Helper Functions ========================
  
  /**
   * Display inline error message for a specific form field
   * @param {string} fieldName - Field identifier ('fullname', 'email', 'event')
   * @param {string} message - Error message to display (empty string clears error)
   */
  function setFieldError(fieldName, message) {
    let errorDiv = null;
    let inputElement = null;
    
    // Map field name to DOM elements
    if (fieldName === 'fullname') {
      errorDiv = nameErrorDiv;
      inputElement = nameInput;
    } else if (fieldName === 'email') {
      errorDiv = emailErrorDiv;
      inputElement = emailInput;
    } else if (fieldName === 'event') {
      errorDiv = eventErrorDiv;
      inputElement = eventSelect;
    }

    if (errorDiv) {
      if (message) {
        // Show error with message and highlight the input
        errorDiv.textContent = message;
        errorDiv.style.display = 'flex';
        if (inputElement) inputElement.style.borderColor = '#e11d48';
      } else {
        // Clear error and restore normal border
        errorDiv.textContent = '';
        errorDiv.style.display = 'none';
        if (inputElement) inputElement.style.borderColor = '#e2e8f0';
      }
    }
  }

  /**
   * Clear all inline error messages and reset input borders
   */
  function clearAllInlineErrors() {
    setFieldError('fullname', '');
    setFieldError('email', '');
    setFieldError('event', '');
    nameInput.style.borderColor = '#e2e8f0';
    emailInput.style.borderColor = '#e2e8f0';
    eventSelect.style.borderColor = '#e2e8f0';
  }

  /**
   * Update the status message area with different styles
   * @param {string} type - 'success', 'error', or 'info'
   * @param {string} message - Message to display
   */
  function updateStatus(type, message) {
    if (!liveStatusMsg) return;
    
    // Remove all existing style classes
    liveStatusMsg.classList.remove('success', 'error', 'info');
    
    // Add appropriate class and set message with icon
    if (type === 'success') {
      liveStatusMsg.classList.add('success');
      liveStatusMsg.innerHTML = `✅ ${message}`;
    } else if (type === 'error') {
      liveStatusMsg.classList.add('error');
      liveStatusMsg.innerHTML = `❌ ${message}`;
    } else {
      liveStatusMsg.classList.add('info');
      liveStatusMsg.innerHTML = `ℹ️ ${message}`;
    }
  }

  /**
   * Validate all form inputs and display inline errors
   * @returns {boolean} True if all inputs are valid, false otherwise
   */
  function validateForm() {
    clearAllInlineErrors();
    let isValid = true;

    // === Full Name Validation ===
    const nameValue = nameInput.value.trim();
    if (nameValue === '') {
      setFieldError('fullname', 'Full name is required.');
      isValid = false;
    } else if (nameValue.length < 2) {
      setFieldError('fullname', 'Name must be at least 2 characters.');
      isValid = false;
    } else if (!/^[a-zA-Zàáâäãåçèéêëìíîïñòóôöõùúûüýÿæœ\s\-']+$/.test(nameValue)) {
      setFieldError('fullname', 'Use letters, spaces, hyphens only.');
      isValid = false;
    }

    // === Email Validation ===
    const emailValue = emailInput.value.trim();
    const emailPattern = /^[^\s@]+@([^\s@.,]+\.)+[^\s@.,]{2,}$/;
    if (emailValue === '') {
      setFieldError('email', 'Email address is required.');
      isValid = false;
    } else if (!emailPattern.test(emailValue)) {
      setFieldError('email', 'Enter a valid email (e.g., name@domain.com).');
      isValid = false;
    }

    // === Event Selection Validation ===
    const eventValue = eventSelect.value;
    if (!eventValue || eventValue === '') {
      setFieldError('event', 'Please select an event from the list.');
      isValid = false;
    }

    return isValid;
  }

  /**
   * Get form data as an object for submission
   * @returns {Object} Form data containing name, email, and selected event
   */
  function getFormData() {
    return {
      fullname: nameInput.value.trim(),
      email: emailInput.value.trim(),
      selectedEvent: eventSelect.value,
      registeredAt: new Date().toISOString()
    };
  }

  /**
   * Enable or disable the submit button during async operations
   * @param {boolean} isLoading - True to disable button and show loading text
   */
  function setLoadingState(isLoading) {
    if (isLoading) {
      submitBtn.disabled = true;
      submitBtn.textContent = '⏳ Sending...';
    } else {
      submitBtn.disabled = false;
      submitBtn.textContent = '✨ Register & Send';
    }
  }

  /**
   * Send user registration data to a mock API using fetch()
   * Includes setTimeout to simulate delayed network response
   * @param {Object} userData - User registration data
   * @returns {Promise<Object>} API response data
   */
  async function sendRegistrationToMockAPI(userData) {
    // First, simulate network latency with setTimeout
    // This fulfills the requirement: "Use setTimeout() to simulate a delayed response"
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Then perform actual fetch POST request to a mock API endpoint
    // reqres.in is a free mock API that accepts POST requests and returns fake data
    const response = await fetch('https://reqres.in/api/users', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: userData.fullname,
        email: userData.email,
        event: userData.selectedEvent,
        source: 'exercise12_ajax'
      })
    });
    
    // Check if the response was successful
    if (!response.ok) {
      throw new Error(`Server responded with status ${response.status}`);
    }
    
    // Parse and return the JSON response
    const responseData = await response.json();
    return responseData;
  }

  // ======================== Main Event Handlers ========================

  /**
   * Main form submission handler
   * - Prevents default form behavior (no page reload)
   * - Validates all inputs with inline errors
   * - Sends data via fetch() to mock API
   * - Shows success/failure messages
   */
  async function handleFormSubmit(event) {
    // PREVENT DEFAULT FORM BEHAVIOR - important requirement
    event.preventDefault();
    
    // VALIDATE INPUTS AND SHOW INLINE ERRORS
    const isValid = validateForm();
    if (!isValid) {
      updateStatus('error', 'Please fix the errors highlighted above before submitting.');
      
      // Smooth scroll to the first error for better UX
      const firstErrorField = document.querySelector('.error-message[style*="display: flex"]');
      if (firstErrorField) {
        firstErrorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }
    
    // Get the form data
    const userData = getFormData();
    
    // Show pending status
    updateStatus('info', `⏳ Registering ${userData.fullname} for "${userData.selectedEvent}" ... (simulated network delay)`);
    
    // Disable submit button to prevent double submission
    setLoadingState(true);
    
    try {
      // SEND USER REGISTRATION TO SERVER USING FETCH()
      // This includes the setTimeout delay inside the function
      const responseData = await sendRegistrationToMockAPI(userData);
      
      // SHOW SUCCESS MESSAGE AFTER SUBMISSION
      updateStatus('success', `🎉 Welcome ${userData.fullname}! Successfully registered for "${userData.selectedEvent}". Mock user ID: ${responseData.id || 'generated'}`);
      
      // Clear any lingering error styles
      clearAllInlineErrors();
      
      // Optional: you could reset the form here if desired
      // form.reset();
      
    } catch (error) {
      // SHOW FAILURE MESSAGE AFTER SUBMISSION
      console.error('Registration error:', error);
      let errorMessage = 'Registration failed. Please try again later.';
      
      if (error.message.includes('Failed to fetch')) {
        errorMessage = 'Network error: Unable to reach the server. Please check your connection.';
      } else {
        errorMessage = `Submission error: ${error.message}`;
      }
      
      updateStatus('error', errorMessage);
      
    } finally {
      // Re-enable the submit button
      setLoadingState(false);
    }
  }

  /**
   * Reset the entire form
   * - Clears all input fields
   * - Removes all error messages
   * - Resets status message
   */
  function resetFormFields() {
    // Reset native form fields
    form.reset();
    
    // Manually ensure select dropdown shows placeholder
    if (eventSelect.options[0] && eventSelect.options[0].value === "") {
      eventSelect.selectedIndex = 0;
    }
    
    // Clear all values (redundant but thorough)
    nameInput.value = '';
    emailInput.value = '';
    
    // Clear all error messages and styles
    clearAllInlineErrors();
    
    // Reset status message
    updateStatus('info', 'Form cleared. You can submit new registration.');
    
    // Ensure submit button is enabled if it was disabled
    setLoadingState(false);
  }

  /**
   * Clear a specific field's error when user starts typing
   * Provides real-time feedback improvement
   */
  function setupRealTimeErrorClearing() {
    nameInput.addEventListener('input', () => {
      setFieldError('fullname', '');
      nameInput.style.borderColor = '#e2e8f0';
    });
    
    emailInput.addEventListener('input', () => {
      setFieldError('email', '');
      emailInput.style.borderColor = '#e2e8f0';
    });
    
    eventSelect.addEventListener('change', () => {
      setFieldError('event', '');
      eventSelect.style.borderColor = '#e2e8f0';
    });
  }

  // ======================== Event Binding ========================
  
  // Attach submit handler to the form (prevents default behavior)
  form.addEventListener('submit', handleFormSubmit);
  
  // Attach reset button handler
  resetBtn.addEventListener('click', resetFormFields);
  
  // Setup real-time error clearing for better UX
  setupRealTimeErrorClearing();
  
  // Initial status message
  updateStatus('info', 'Fill in your details and submit — simulated API request with setTimeout delay');
});
document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevents page refresh

    // Task: Log form submission steps
    console.log("Form submission process started...");

    try {
        const username = document.getElementById('username').value;
        
        // BUG 1: Accessing 'email' instead of 'userEmail'. 
        // This will cause an error because .value cannot be read from null.
        const email = document.getElementById('email').value; 
        
        const password = document.getElementById('password').value;

        const payload = { username, email, password };

        // Task: Check fetch request payload in Console
        console.log("Request Payload:", payload);

        // Simulated API Call
        fetch('https://typicode.com', {
            method: 'POST',
            body: JSON.stringify(payload),
            headers: { 'Content-type': 'application/json' }
        })
        .then(response => {
            if (response.ok) {
                console.log("Server Response: Success!");
                // BUG 2: Silent failure - No UI update is given to the user here.
            }
        })
        .catch(err => {
            // Task: Use Console to see this hidden error
            console.error("Fetch error:", err);
        });

    } catch (error) {
        // Silent failure: The error is caught but not shown on the webpage
        console.error("A silent error occurred during processing:", error.message);
    }
});
$(document).ready(function() {
    // 1. Handle click event on the register button
    $('#registerBtn').click(function() {
        let card = $('.event-card');

        // 2. Use fadeIn() and fadeOut() logic
        if (card.is(':visible')) {
            card.fadeOut(500); // Fades out over 500ms
            $(this).text("Show Event Details");
        } else {
            card.fadeIn(500);  // Fades in over 500ms
            $(this).text("Hide Event Details");
        }
    });
});