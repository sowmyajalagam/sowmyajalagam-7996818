USE ansi_sql_mysql_assignment;

DROP TABLE IF EXISTS Resources;
DROP TABLE IF EXISTS Feedback;
DROP TABLE IF EXISTS Registrations;
DROP TABLE IF EXISTS Sessions;
DROP TABLE IF EXISTS Events;
DROP TABLE IF EXISTS Users;

CREATE TABLE Users (
  user_id INT PRIMARY KEY AUTO_INCREMENT,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  city VARCHAR(100) NOT NULL,
  registration_date DATE NOT NULL
) ENGINE=InnoDB;

CREATE TABLE Events (
  event_id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  city VARCHAR(100) NOT NULL,
  start_date DATETIME NOT NULL,
  end_date DATETIME NOT NULL,
  status ENUM('upcoming','completed','cancelled') NOT NULL,
  organizer_id INT NOT NULL,
  CONSTRAINT fk_events_organizer
    FOREIGN KEY (organizer_id) REFERENCES Users(user_id),
  CONSTRAINT chk_events_dates
    CHECK (end_date >= start_date)
) ENGINE=InnoDB;

CREATE TABLE Sessions (
  session_id INT PRIMARY KEY AUTO_INCREMENT,
  event_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  speaker_name VARCHAR(100) NOT NULL,
  start_time DATETIME NOT NULL,
  end_time DATETIME NOT NULL,
  CONSTRAINT fk_sessions_event
    FOREIGN KEY (event_id) REFERENCES Events(event_id),
  CONSTRAINT chk_sessions_times
    CHECK (end_time > start_time)
) ENGINE=InnoDB;

CREATE TABLE Registrations (
  registration_id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  event_id INT NOT NULL,
  registration_date DATE NOT NULL,
  CONSTRAINT fk_registrations_user
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
  CONSTRAINT fk_registrations_event
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
) ENGINE=InnoDB;

CREATE TABLE Feedback (
  feedback_id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  event_id INT NOT NULL,
  rating INT NOT NULL,
  comments TEXT,
  feedback_date DATE NOT NULL,
  CONSTRAINT fk_feedback_user
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
  CONSTRAINT fk_feedback_event
    FOREIGN KEY (event_id) REFERENCES Events(event_id),
  CONSTRAINT chk_feedback_rating
    CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

CREATE TABLE Resources (
  resource_id INT PRIMARY KEY AUTO_INCREMENT,
  event_id INT NOT NULL,
  resource_type ENUM('pdf','image','link') NOT NULL,
  resource_url VARCHAR(255) NOT NULL,
  uploaded_at DATETIME NOT NULL,
  CONSTRAINT fk_resources_event
    FOREIGN KEY (event_id) REFERENCES Events(event_id)
) ENGINE=InnoDB;
