# Explanation

Q1:
Purpose: List upcoming events a user is registered for in the same city.
Logic Used: Join Registrations, Users, and Events, filter by upcoming status and matching city, sort by start date.
Expected Result: Each qualifying user-event pair ordered by event date.

Q2:
Purpose: Find events with the highest average rating among those with at least 10 feedback entries.
Logic Used: Aggregate average rating per event with a HAVING threshold, then select the max average.
Expected Result: One or more top-rated events with their average rating and feedback count.

Q3:
Purpose: Identify users with no registrations in the last 90 days.
Logic Used: Use NOT EXISTS against recent registrations for each user.
Expected Result: Users who are inactive based on registration activity.

Q4:
Purpose: Count sessions starting between 10 AM and 12 PM for each event.
Logic Used: Conditional join on Sessions with time filter, grouped by event.
Expected Result: Events with a count of sessions that start in the specified time window.

Q5:
Purpose: Show the top cities by distinct registered users.
Logic Used: Join Registrations to Users and count distinct users per city, order and limit.
Expected Result: Up to five cities with the highest distinct registration counts.

Q6:
Purpose: Summarize uploaded resources by type for each event.
Logic Used: Left join Resources and use conditional aggregation for each resource type.
Expected Result: Per-event counts of PDFs, images, links, and total resources.

Q7:
Purpose: Surface low ratings with user comments and event names.
Logic Used: Join Feedback, Users, and Events, filter rating < 3.
Expected Result: Rows containing user, event, rating, comments, and date.

Q8:
Purpose: Count sessions for each upcoming event.
Logic Used: Filter Events by upcoming status and left join Sessions with grouping.
Expected Result: Upcoming events with their scheduled session counts.

Q9:
Purpose: Summarize event counts by organizer and status.
Logic Used: Join Events to Users and aggregate totals with status-specific counts.
Expected Result: One row per organizer with totals for upcoming, completed, and cancelled.

Q10:
Purpose: Find events that have registrations but no feedback.
Logic Used: Join Events and Registrations, left join Feedback, group and filter with HAVING.
Expected Result: Events that have at least one registration and zero feedback.

Q11:
Purpose: Count new users per day for the last 7 days.
Logic Used: Filter Users by registration_date and group by day.
Expected Result: Daily counts of new users in the recent 7-day window.

Q12:
Purpose: Identify the event(s) with the maximum number of sessions.
Logic Used: Compute session counts per event and select the maximum via a CTE.
Expected Result: Event rows tied for the highest session count.

Q13:
Purpose: Compute average feedback rating by event city.
Logic Used: Join Events and Feedback and aggregate by city.
Expected Result: Each city with its average feedback rating.

Q14:
Purpose: List the top 3 events by total registrations.
Logic Used: Join Events and Registrations and order by registration count with a limit.
Expected Result: Three events with the highest registration totals.

Q15:
Purpose: Detect overlapping sessions within the same event.
Logic Used: Self-join Sessions on the same event with overlap conditions and ordered pairs.
Expected Result: Pairs of sessions that conflict in time.

Q16:
Purpose: Find recent users without any event registrations.
Logic Used: Filter Users to last 30 days and exclude those with registrations using NOT EXISTS.
Expected Result: New users who have not registered for any events.

Q17:
Purpose: Identify speakers with more than one session.
Logic Used: Group Sessions by speaker_name and apply HAVING count > 1.
Expected Result: Speakers handling multiple sessions.

Q18:
Purpose: List events that have no resources uploaded.
Logic Used: Left join Resources and filter to null matches.
Expected Result: Events without any resources.

Q19:
Purpose: Provide registration counts and average ratings for completed events.
Logic Used: Filter Events by completed status and aggregate registrations and feedback.
Expected Result: Completed events with total registrations and average rating.

Q20:
Purpose: Compute each user's event attendance and feedback submissions.
Logic Used: Aggregate registrations and feedback by user, then left join to Users with COALESCE.
Expected Result: One row per user with counts for attended events and feedbacks.

Q21:
Purpose: List users with the most feedback entries.
Logic Used: Join Users and Feedback, group by user, order by count, limit to five.
Expected Result: Top five feedback contributors.

Q22:
Purpose: Detect duplicate registrations for the same user and event.
Logic Used: Group Registrations by user and event and filter counts greater than one.
Expected Result: User-event combinations that appear more than once.

Q23:
Purpose: Show monthly registration trends for the last 12 months.
Logic Used: Filter by date range and group by year-month, ordered chronologically.
Expected Result: A time series of registration counts by month.

Q24:
Purpose: Calculate average session duration per event in minutes.
Logic Used: Use TIMESTAMPDIFF to compute durations and average by event.
Expected Result: Per-event average session length in minutes.

Q25:
Purpose: List events that currently have no sessions.
Logic Used: Left join Sessions and filter to null matches.
Expected Result: Events with zero sessions scheduled.
