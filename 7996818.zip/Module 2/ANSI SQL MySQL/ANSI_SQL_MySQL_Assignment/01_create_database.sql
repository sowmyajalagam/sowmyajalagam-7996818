
CREATE DATABASE IF NOT EXISTS ansi_sql_mysql_assignment
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

USE ansi_sql_mysql_assignment;
