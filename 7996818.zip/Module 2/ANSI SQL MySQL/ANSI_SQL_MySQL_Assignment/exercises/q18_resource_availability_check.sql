USE ansi_sql_mysql_assignment;

SELECT e.event_id,
       e.title
FROM Events e
LEFT JOIN Resources r ON e.event_id = r.event_id
WHERE r.resource_id IS NULL
ORDER BY e.event_id;
