USE ansi_sql_mysql_assignment;

SELECT u.registration_date,
       COUNT(*) AS new_user_count
FROM Users u
WHERE u.registration_date >= CURRENT_DATE - INTERVAL 7 DAY
GROUP BY u.registration_date
ORDER BY u.registration_date;
