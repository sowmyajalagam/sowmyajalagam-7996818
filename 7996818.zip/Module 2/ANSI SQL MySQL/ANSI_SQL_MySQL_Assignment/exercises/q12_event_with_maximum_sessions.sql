USE ansi_sql_mysql_assignment;

WITH session_counts AS (
  SELECT e.event_id,
         e.title,
         COUNT(s.session_id) AS session_count
  FROM Events e
  LEFT JOIN Sessions s ON e.event_id = s.event_id
  GROUP BY e.event_id, e.title
),
max_count AS (
  SELECT MAX(session_count) AS max_session_count
  FROM session_counts
)
SELECT sc.event_id,
       sc.title,
       sc.session_count
FROM session_counts sc
JOIN max_count mc ON sc.session_count = mc.max_session_count
ORDER BY sc.event_id;
