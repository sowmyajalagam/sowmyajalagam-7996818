USE ansi_sql_mysql_assignment;

SELECT r.user_id,
       u.full_name,
       r.event_id,
       e.title AS event_title,
       COUNT(*) AS registration_count
FROM Registrations r
JOIN Users u ON r.user_id = u.user_id
JOIN Events e ON r.event_id = e.event_id
GROUP BY r.user_id, u.full_name, r.event_id, e.title
HAVING COUNT(*) > 1
ORDER BY r.user_id, r.event_id;
