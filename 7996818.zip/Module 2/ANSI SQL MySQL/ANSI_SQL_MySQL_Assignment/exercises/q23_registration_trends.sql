USE ansi_sql_mysql_assignment;

SELECT DATE_FORMAT(r.registration_date, '%Y-%m') AS year_month,
       COUNT(*) AS registration_count
FROM Registrations r
WHERE r.registration_date >= CURRENT_DATE - INTERVAL 12 MONTH
GROUP BY DATE_FORMAT(r.registration_date, '%Y-%m')
ORDER BY year_month;
