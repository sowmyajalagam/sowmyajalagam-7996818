USE ansi_sql_mysql_assignment;

WITH reg_counts AS (
  SELECT r.user_id,
         COUNT(DISTINCT r.event_id) AS events_attended
  FROM Registrations r
  GROUP BY r.user_id
),
feedback_counts AS (
  SELECT f.user_id,
         COUNT(*) AS feedbacks_submitted
  FROM Feedback f
  GROUP BY f.user_id
)
SELECT u.user_id,
       u.full_name,
       COALESCE(rc.events_attended, 0) AS events_attended,
       COALESCE(fc.feedbacks_submitted, 0) AS feedbacks_submitted
FROM Users u
LEFT JOIN reg_counts rc ON u.user_id = rc.user_id
LEFT JOIN feedback_counts fc ON u.user_id = fc.user_id
ORDER BY u.user_id;
