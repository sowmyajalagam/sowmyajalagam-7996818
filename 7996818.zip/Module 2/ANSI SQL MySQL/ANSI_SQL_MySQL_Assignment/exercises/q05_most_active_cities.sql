USE ansi_sql_mysql_assignment;

SELECT u.city,
       COUNT(DISTINCT r.user_id) AS distinct_registered_users
FROM Registrations r
JOIN Users u ON r.user_id = u.user_id
GROUP BY u.city
ORDER BY distinct_registered_users DESC, u.city
LIMIT 5;
