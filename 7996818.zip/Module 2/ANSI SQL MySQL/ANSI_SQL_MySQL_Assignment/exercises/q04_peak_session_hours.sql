USE ansi_sql_mysql_assignment;

SELECT e.event_id,
       e.title,
       COUNT(s.session_id) AS sessions_10_to_12
FROM Events e
LEFT JOIN Sessions s
  ON e.event_id = s.event_id
 AND TIME(s.start_time) BETWEEN '10:00:00' AND '12:00:00'
GROUP BY e.event_id, e.title
ORDER BY e.event_id;
