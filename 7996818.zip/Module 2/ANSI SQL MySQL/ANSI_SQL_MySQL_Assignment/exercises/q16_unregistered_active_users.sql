USE ansi_sql_mysql_assignment;

SELECT u.user_id,
       u.full_name,
       u.email,
       u.registration_date
FROM Users u
WHERE u.registration_date >= CURRENT_DATE - INTERVAL 30 DAY
  AND NOT EXISTS (
    SELECT 1
    FROM Registrations r
    WHERE r.user_id = u.user_id
  )
ORDER BY u.user_id;
