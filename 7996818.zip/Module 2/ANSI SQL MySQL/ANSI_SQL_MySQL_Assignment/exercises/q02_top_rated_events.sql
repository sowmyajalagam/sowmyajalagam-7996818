USE ansi_sql_mysql_assignment;

WITH rated_events AS (
  SELECT e.event_id,
         e.title,
         AVG(f.rating) AS avg_rating,
         COUNT(*) AS feedback_count
  FROM Events e
  JOIN Feedback f ON e.event_id = f.event_id
  GROUP BY e.event_id, e.title
  HAVING COUNT(*) >= 10
),
max_rating AS (
  SELECT MAX(avg_rating) AS max_avg_rating
  FROM rated_events
)
SELECT r.event_id,
       r.title,
       r.avg_rating,
       r.feedback_count
FROM rated_events r
JOIN max_rating m ON r.avg_rating = m.max_avg_rating;
