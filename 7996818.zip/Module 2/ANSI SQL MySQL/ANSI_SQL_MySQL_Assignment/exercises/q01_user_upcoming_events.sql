USE ansi_sql_mysql_assignment;

SELECT u.user_id,
       u.full_name,
       e.event_id,
       e.title,
       e.city,
       e.start_date
FROM Registrations r
JOIN Users u ON r.user_id = u.user_id
JOIN Events e ON r.event_id = e.event_id
WHERE e.status = 'upcoming'
  AND e.city = u.city
ORDER BY e.start_date, u.user_id;
