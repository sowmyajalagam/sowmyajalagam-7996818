USE ansi_sql_mysql_assignment;

SELECT e.event_id,
       e.title
FROM Events e
JOIN Registrations r ON r.event_id = e.event_id
LEFT JOIN Feedback f ON f.event_id = e.event_id
GROUP BY e.event_id, e.title
HAVING COUNT(f.feedback_id) = 0
ORDER BY e.event_id;
