USE ansi_sql_mysql_assignment;

SELECT u.user_id,
       u.full_name,
       u.email,
       u.city,
       u.registration_date
FROM Users u
WHERE NOT EXISTS (
  SELECT 1
  FROM Registrations r
  WHERE r.user_id = u.user_id
    AND r.registration_date >= CURRENT_DATE - INTERVAL 90 DAY
)
ORDER BY u.user_id;
