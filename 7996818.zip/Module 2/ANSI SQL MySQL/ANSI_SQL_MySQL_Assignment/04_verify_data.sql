USE ansi_sql_mysql_assignment;

SELECT 'Users' AS table_name, COUNT(*) AS row_count FROM Users
UNION ALL
SELECT 'Events', COUNT(*) FROM Events
UNION ALL
SELECT 'Sessions', COUNT(*) FROM Sessions
UNION ALL
SELECT 'Registrations', COUNT(*) FROM Registrations
UNION ALL
SELECT 'Feedback', COUNT(*) FROM Feedback
UNION ALL
SELECT 'Resources', COUNT(*) FROM Resources;

SELECT 'Events.organizer_id -> Users.user_id' AS fk_check,
       COUNT(*) AS orphan_count
FROM Events e
LEFT JOIN Users u ON e.organizer_id = u.user_id
WHERE u.user_id IS NULL;

SELECT 'Sessions.event_id -> Events.event_id' AS fk_check,
       COUNT(*) AS orphan_count
FROM Sessions s
LEFT JOIN Events e ON s.event_id = e.event_id
WHERE e.event_id IS NULL;

SELECT 'Registrations.user_id -> Users.user_id' AS fk_check,
       COUNT(*) AS orphan_count
FROM Registrations r
LEFT JOIN Users u ON r.user_id = u.user_id
WHERE u.user_id IS NULL;

SELECT 'Registrations.event_id -> Events.event_id' AS fk_check,
       COUNT(*) AS orphan_count
FROM Registrations r
LEFT JOIN Events e ON r.event_id = e.event_id
WHERE e.event_id IS NULL;

SELECT 'Feedback.user_id -> Users.user_id' AS fk_check,
       COUNT(*) AS orphan_count
FROM Feedback f
LEFT JOIN Users u ON f.user_id = u.user_id
WHERE u.user_id IS NULL;

SELECT 'Feedback.event_id -> Events.event_id' AS fk_check,
       COUNT(*) AS orphan_count
FROM Feedback f
LEFT JOIN Events e ON f.event_id = e.event_id
WHERE e.event_id IS NULL;

SELECT 'Resources.event_id -> Events.event_id' AS fk_check,
       COUNT(*) AS orphan_count
FROM Resources r
LEFT JOIN Events e ON r.event_id = e.event_id
WHERE e.event_id IS NULL;

SELECT e.event_id,
       e.title,
       e.status,
       u.full_name AS organizer
FROM Events e
JOIN Users u ON e.organizer_id = u.user_id
ORDER BY e.event_id;

SELECT e.event_id,
       e.title,
       COUNT(r.registration_id) AS registrations
FROM Events e
LEFT JOIN Registrations r ON e.event_id = r.event_id
GROUP BY e.event_id, e.title
ORDER BY e.event_id;

SELECT e.event_id,
       e.title,
       AVG(f.rating) AS avg_rating
FROM Events e
LEFT JOIN Feedback f ON e.event_id = f.event_id
GROUP BY e.event_id, e.title
ORDER BY e.event_id;
