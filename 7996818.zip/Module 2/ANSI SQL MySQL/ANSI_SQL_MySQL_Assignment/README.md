# ANSI SQL Using MySQL Assignment

## Project Overview
This project contains schema creation, sample data, verification queries, and ANSI SQL exercises implemented in MySQL 8+. It is based on the provided "ANSI SQL Using MySQL" module and follows a structured execution order.

## Database Schema
- Users: user_id (PK), full_name, email (UNIQUE), city, registration_date
- Events: event_id (PK), title, description, city, start_date, end_date, status, organizer_id (FK -> Users)
- Sessions: session_id (PK), event_id (FK -> Events), title, speaker_name, start_time, end_time
- Registrations: registration_id (PK), user_id (FK -> Users), event_id (FK -> Events), registration_date
- Feedback: feedback_id (PK), user_id (FK -> Users), event_id (FK -> Events), rating (CHECK 1-5), comments, feedback_date
- Resources: resource_id (PK), event_id (FK -> Events), resource_type (ENUM), resource_url, uploaded_at

## MySQL Version
- MySQL 8.0 or later

## Setup Instructions
1. Ensure MySQL 8+ is installed and accessible via CLI or a GUI client.
2. Use a MySQL user with privileges to create databases and tables.
3. Execute the scripts in the order listed below.

## Execution Order
1. 01_create_database.sql
2. 02_create_tables.sql
3. 03_insert_sample_data.sql
4. 04_verify_data.sql
5. All files in exercises/ in numeric order

## How to Execute Files
Using the mysql CLI from the project root:

- mysql -u <user> -p < 01_create_database.sql
- mysql -u <user> -p ansi_sql_mysql_assignment < 02_create_tables.sql
- mysql -u <user> -p ansi_sql_mysql_assignment < 03_insert_sample_data.sql
- mysql -u <user> -p ansi_sql_mysql_assignment < 04_verify_data.sql

Then run each exercise script:

- mysql -u <user> -p ansi_sql_mysql_assignment < exercises/q01_user_upcoming_events.sql
- ...
- mysql -u <user> -p ansi_sql_mysql_assignment < exercises/q25_events_without_sessions.sql
