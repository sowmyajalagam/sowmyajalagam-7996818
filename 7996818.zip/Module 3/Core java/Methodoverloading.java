public class Methodoverloading {

    public static int add(int a, int b) {
        return a + b;
    }
    
    // Method 2: Add two doubles
    public static double add(double a, double b) {
        return a + b;
    }
    
    // Method 3: Add three integers
    public static int add(int a, int b, int c) {
        return a + b + c;
    }
    
    public static void main(String[] args) {
        System.out.println("Method Overloading Demonstration:");
        System.out.println("--------------------------------");
        
        // Call method with two integers
        int sum1 = add(10, 20);
        System.out.println("add(10, 20) = " + sum1);
        
        // Call method with two doubles
        double sum2 = add(5.5, 3.7);
        System.out.println("add(5.5, 3.7) = " + sum2);
        
        // Call method with three integers
        int sum3 = add(8, 12, 5);
        System.out.println("add(8, 12, 5) = " + sum3);
        
        // Bonus: Demonstrate that return type alone doesn't count for overloading
        System.out.println("\nNote: Method overloading depends on parameter");
        System.out.println("types, count, or order - not return type.");
    }
}
