import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// Student model class
class Student {
    private int id;
    private String name;
    private int age;
    private String grade;
    private String major;
    
    public Student(int id, String name, int age, String grade, String major) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.grade = grade;
        this.major = major;
    }
    
    @Override
    public String toString() {
        return String.format("Student{id=%d, name='%s', age=%d, grade='%s', major='%s'}", 
                            id, name, age, grade, major);
    }
    
    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getGrade() { return grade; }
    public String getMajor() { return major; }
}

// Database utility class
class DatabaseUtil {
    private static final String URL = "jdbc:sqlite:students.db";
    
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }
    
    public static List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students ORDER BY id";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                students.add(new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getString("grade"),
                    rs.getString("major")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching students: " + e.getMessage());
        }
        return students;
    }
    
    public static Student getStudentById(int id) {
        String sql = "SELECT * FROM students WHERE id = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getString("grade"),
                    rs.getString("major")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error fetching student: " + e.getMessage());
        }
        return null;
    }
}

// Main demo class
public class JDBCDemo {
    public static void main(String[] args) {
        System.out.println("=== JDBC Utility Demo ===\n");
        
        // Get all students
        List<Student> students = DatabaseUtil.getAllStudents();
        System.out.println("All students:");
        students.forEach(System.out::println);
        
        // Get student by ID
        System.out.println("\n--- Searching for student ID 2 ---");
        Student student = DatabaseUtil.getStudentById(2);
        if (student != null) {
            System.out.println("Found: " + student);
        } else {
            System.out.println("Student not found");
        }
    }
}