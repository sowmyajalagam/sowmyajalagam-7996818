import java.lang.reflect.Method;

class Demo {
    public void display() {
        System.out.println("Hello from Reflection!");
    }
}

public class ReflectionExample {
    public static void main(String[] args) {
        try {
            // Load class dynamically
            Class<?> cls = Class.forName("Demo");

            // Create object
            Object obj = cls.getDeclaredConstructor().newInstance();

            // Get all methods
            Method[] methods = cls.getDeclaredMethods();

            System.out.println("Methods in Demo class:");

            for (Method m : methods) {
                System.out.println("Method Name: " + m.getName());

                // Invoke display() method
                if (m.getName().equals("display")) {
                    m.invoke(obj);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}