import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileReadingExercise {
    public static void main(String[] args) {
        System.out.println("Reading contents of output.txt...");
        System.out.println("--------------------------------");
        
        // Read and display the contents of output.txt
        try (BufferedReader reader = new BufferedReader(new FileReader("output.txt"))) {
            String line;
            boolean hasContent = false;
            
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
                hasContent = true;
            }
            
            if (!hasContent) {
                System.out.println("The file is empty.");
            }
            
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
            System.out.println("Make sure output.txt exists and is accessible.");
        }
        
        System.out.println("--------------------------------");
        System.out.println("File reading completed.");
    }
}