import java.util.Scanner;

public class FactorialCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Prompt the user for a non-negative integer
        System.out.print("Enter a non-negative integer: ");
        int number = scanner.nextInt();
    
        // Validate input
        if (number < 0) {
            System.out.println("Error: Factorial is not defined for negative numbers.");
        } else {
            // Calculate factorial using a for loop
            long factorial = 1;  // Using long to handle larger results
            
            for (int i = 1; i <= number; i++) {
                factorial *= i;  // Same as: factorial = factorial * i
            }
            
            // Display the result
            System.out.println(number + "! = " + factorial);
        }
        
        scanner.close();
    }
}