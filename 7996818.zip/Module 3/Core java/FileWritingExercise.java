import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileWritingExercise {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Prompt the user for a string
        System.out.print("Enter a string to write to the file: ");
        String userInput = scanner.nextLine();
        
        // Write the string to a file named output.txt
        try (FileWriter writer = new FileWriter("output.txt")) {
            writer.write(userInput);
            System.out.println("Data has been successfully written to output.txt");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
        
        scanner.close();
    }
}