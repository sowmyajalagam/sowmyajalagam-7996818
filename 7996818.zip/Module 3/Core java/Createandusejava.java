class Utility {
    public static void greet() {
        System.out.println("Hello from Utility Class!");
    }
}

public class Main {
    public static void main(String[] args) {
        Utility.greet();
    }
}