public class HelloWorld {
    public static void main(String[] args) {
        // Use System.out.println() to display the message
        System.out.println("Hello, World!");
    }
}