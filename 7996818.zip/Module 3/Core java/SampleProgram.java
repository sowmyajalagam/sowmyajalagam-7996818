public class SampleProgram {
    private String message = "Hello Java";
    
    public SampleProgram() {
        System.out.println("Constructor called");
    }
    
    public void greet(String name) {
        String greeting = message + ", " + name + "!";
        System.out.println(greeting);
    }
    
    private int calculate(int a, int b) {
        int result = a * a + b * b;
        return result;
    }
    
    public static void main(String[] args) {
        SampleProgram sp = new SampleProgram();
        sp.greet("Developer");
        
        int sumOfSquares = sp.calculate(3, 4);
        System.out.println("Sum of squares: " + sumOfSquares);
        
        // Loop example
        for(int i = 1; i <= 3; i++) {
            System.out.println("Count: " + i);
        }
    }
}