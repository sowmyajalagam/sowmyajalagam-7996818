import java.util.Arrays;
import java.util.List;

public class LambdaSimpleDemo {
    public static void main(String[] args) {
        // Create and initialize list
        List<String> names = Arrays.asList("Charlie", "Alice", "Bob", "David");
        
        System.out.println("Original: " + names);
        
        // Sort using lambda expression
        names.sort((a, b) -> a.compareTo(b));
        
        System.out.println("Sorted: " + names);
    }
}