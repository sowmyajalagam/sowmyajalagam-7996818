import java.util.List;
import java.util.stream.Collectors;

// Define a record named Person (Java 16+)
record Person(String name, int age) {
    // Compact constructor for validation (optional)
    public Person {
        if (age < 0) {
            throw new IllegalArgumentException("Age cannot be negative");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        }
    }
    
    // Additional methods can be added
    public String greeting() {
        return "Hello, my name is " + name + " and I am " + age + " years old.";
    }
}

public class RecordsDemo {
    public static void main(String[] args) {
        System.out.println("=== Basic Record Usage ===\n");
        
        // Create instances of Person record
        Person person1 = new Person("Alice", 25);
        Person person2 = new Person("Bob", 30);
        Person person3 = new Person("Charlie", 17);
        
        // Print the records
        System.out.println("person1: " + person1);
        System.out.println("person2: " + person2);
        System.out.println("person3: " + person3);
        
        // Accessing components using accessor methods
        System.out.println("\n=== Accessing Components ===");
        System.out.println(person1.name() + " is " + person1.age() + " years old");
        System.out.println(person2.name() + " is " + person2.age() + " years old");
        
        // Using record methods
        System.out.println("\n=== Using Record Methods ===");
        System.out.println(person1.greeting());
        
        // Record provides equals(), hashCode(), toString() automatically
        System.out.println("\n=== Automatic Methods ===");
        Person person1Copy = new Person("Alice", 25);
        System.out.println("person1 equals person1Copy: " + person1.equals(person1Copy));
        System.out.println("person1 hashCode: " + person1.hashCode());
        System.out.println("person1Copy hashCode: " + person1Copy.hashCode());
        
        // Working with List and Stream API
        System.out.println("\n=== Records in List with Stream API ===");
        
        List<Person> people = List.of(
            new Person("Alice", 25),
            new Person("Bob", 30),
            new Person("Charlie", 17),
            new Person("Diana", 22),
            new Person("Eve", 35),
            new Person("Frank", 16)
        );
        
        System.out.println("All people:");
        people.forEach(System.out::println);
        
        // Filter based on age using Streams
        System.out.println("\n--- Adults (age >= 18) ---");
        List<Person> adults = people.stream()
                                    .filter(p -> p.age() >= 18)
                                    .collect(Collectors.toList());
        adults.forEach(System.out::println);
        
        // Filter minors (age < 18)
        System.out.println("\n--- Minors (age < 18) ---");
        List<Person> minors = people.stream()
                                    .filter(p -> p.age() < 18)
                                    .collect(Collectors.toList());
        minors.forEach(System.out::println);
        
        // Filter by age range
        System.out.println("\n--- Age between 20 and 30 ---");
        people.stream()
              .filter(p -> p.age() >= 20 && p.age() <= 30)
              .forEach(System.out::println);
        
        // Map to names only
        System.out.println("\n--- Names of all people ---");
        List<String> names = people.stream()
                                   .map(Person::name)
                                   .collect(Collectors.toList());
        System.out.println(names);
        
        // Group by age category
        System.out.println("\n=== Grouping by Age Category ===");
        var adultsList = people.stream().filter(p -> p.age() >= 18).toList();
        var minorsList = people.stream().filter(p -> p.age() < 18).toList();
        
        System.out.println("Adults: " + adultsList);
        System.out.println("Minors: " + minorsList);
        
        // Using record with pattern matching (Java 21+)
        System.out.println("\n=== Pattern Matching with instanceof ===");
        Object obj = new Person("Test", 20);
        if (obj instanceof Person p) {
            System.out.println("Object is a Person: " + p.name() + ", " + p.age());
        }
        
        // Demonstrate immutability (records are shallowly immutable)
        System.out.println("\n=== Immutability Demo ===");
        Person immutable = new Person("Immutable", 25);
        // immutable.age = 26; // This would cause compilation error
        System.out.println("Record fields are final: " + immutable);
    }
}