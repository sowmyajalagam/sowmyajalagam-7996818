import java.sql.*;

public class JDBCDemo {
    public static void main(String[] args) {
        // Database credentials
        String url = "jdbc:mysql://localhost:3306/testdb";
        String username = "root";  // Change to your MySQL username
        String password = "";      // Change to your MySQL password
        
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            // 1. Load JDBC Driver (optional for newer JDBC versions)
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("✓ Driver loaded successfully");
            
            // 2. Create connection
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("✓ Connected to database");
            
            // 3. Execute SELECT query
            stmt = conn.createStatement();
            String query = "SELECT * FROM students";
            rs = stmt.executeQuery(query);
            
            // 4. Process and print results
            System.out.println("\n--- Students Records ---");
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String grade = rs.getString("grade");
                
                System.out.printf("ID: %d | Name: %s | Age: %d | Grade: %s%n",
                                  id, name, age, grade);
            }
            
        } catch (ClassNotFoundException e) {
            System.out.println("❌ JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("❌ Database error: " + e.getMessage());
        } finally {
            // 5. Close resources (always in finally block)
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
                System.out.println("✓ Resources closed");
            } catch (SQLException e) {
                System.out.println("❌ Error closing resources: " + e.getMessage());
            }
        }
    }
}