public class OperatorPrecedence {
    public static void main(String[] args) {
        
        int a = 10, b = 5, c = 2;
        
        System.out.println("Operator Precedence Demonstration:");
        System.out.println("Initial values: a = " + a + ", b = " + b + ", c = " + c);
        System.out.println();
        
        int result1 = a + b * c;
        System.out.println("a + b * c = " + a + " + " + b + " * " + c + " = " + result1);
        System.out.println("(b * c executes first: " + b + " * " + c + " = " + (b * c) + ")");
        
    
        int result2 = (a + b) * c;
        System.out.println("(a + b) * c = (" + a + " + " + b + ") * " + c + " = " + result2);
        
        int result3 = a / b * c;
        System.out.println("a / b * c = " + a + " / " + b + " * " + c + " = " + result3);
        System.out.println("(Left to right: " + a + " / " + b + " = " + (a / b) + ", then " + (a / b) + " * " + c + ")");
        
        int result4 = a + b % c;
        System.out.println("a + b % c = " + a + " + " + b + " % " + c + " = " + result4);
        System.out.println("(Modulo has higher precedence than addition: " + b + " % " + c + " = " + (b % c) + ")");
        
        int result5 = a + b * c - a / b;
        System.out.println("a + b * c - a / b = " + a + " + " + b + " * " + c + " - " + a + " / " + b + " = " + result5);
    }
}