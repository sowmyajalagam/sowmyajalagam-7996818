import java.util.Scanner;

public class RecursiveFibonacci {
    public static int fibonacci(int n) {
        // Base cases
        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        // Recursive case: F(n) = F(n-1) + F(n-2)
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Prompt the user for a positive integer n
        System.out.print("Enter a positive integer (n): ");
        int n = scanner.nextInt();
        
        // Validate input
        if (n < 0) {
            System.out.println("Please enter a non-negative integer.");
        } else {
            // Calculate and display the nth Fibonacci number
            int result = fibonacci(n);
            System.out.println("The " + n + "th Fibonacci number is: " + result);
            
            // Bonus: Display the Fibonacci sequence up to n
            System.out.print("\nFibonacci sequence up to position " + n + ": ");
            for (int i = 0; i <= n; i++) {
                System.out.print(fibonacci(i));
                if (i < n) {
                    System.out.print(", ");
                }
            }
            System.out.println();
        }
        
        scanner.close();
    }
}