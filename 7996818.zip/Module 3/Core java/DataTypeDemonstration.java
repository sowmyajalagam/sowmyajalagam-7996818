public class DataTypeDemonstration {
    public static void main(String[] args) {
        // Declare variables of different primitive types
        int intValue = 42;
        float floatValue = 3.14f;      // 'f' suffix required for float literals
        double doubleValue = 3.14159265359;
        char charValue = 'A';
        boolean booleanValue = true;
        
        // Display each variable using System.out.println()
        System.out.println("Primitive Data Type Demonstration:");
        System.out.println("int value: " + intValue);
        System.out.println("float value: " + floatValue);
        System.out.println("double value: " + doubleValue);
        System.out.println("char value: " + charValue);
        System.out.println("boolean value: " + booleanValue);
    }
}
