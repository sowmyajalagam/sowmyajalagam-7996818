public class SimplePatternMatchingDemo {
    
    // Simple method to identify object type
    public static void identifyType(Object obj) {
        String result = switch (obj) {
            case null -> "It's null!";
            case Integer i -> "It's an integer: " + i;
            case String s -> "It's a string: \"" + s + "\"";
            case Double d -> "It's a double: " + d;
            case Boolean b -> "It's a boolean: " + b;
            default -> "It's something else: " + obj.getClass().getSimpleName();
        };
        System.out.println(result);
    }
    
    public static void main(String[] args) {
        identifyType(10);
        identifyType("Hello");
        identifyType(3.14);
        identifyType(true);
        identifyType(null);
        identifyType(new Object());
    }
}