import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server waiting for client on port 12345...");
            Socket socket = serverSocket.accept();
            System.out.println("Client connected!");
            
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
            
            Thread receiver = new Thread(() -> {
                try {
                    String msg;
                    while ((msg = input.readLine()) != null)
                        System.out.println("Client: " + msg);
                } catch (IOException e) {}
            });
            receiver.start();
            
            String msg;
            while ((msg = console.readLine()) != null) {
                output.println(msg);
                if (msg.equalsIgnoreCase("quit")) break;
            }
        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }
}

