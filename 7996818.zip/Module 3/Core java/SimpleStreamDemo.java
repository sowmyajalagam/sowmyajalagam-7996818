import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SimpleStreamDemo {
    public static void main(String[] args) {
        // Create a list of integers
        List<Integer> numbers = Arrays.asList(10, 25, 32, 47, 58, 61, 74, 89, 90);
        
        System.out.println("Original list: " + numbers);
        
        // Filter even numbers using Stream API
        List<Integer> evens = numbers.stream()
                                     .filter(num -> num % 2 == 0)
                                     .collect(Collectors.toList());
        
        // Display the result
        System.out.println("Even numbers only: " + evens);
    }
}
