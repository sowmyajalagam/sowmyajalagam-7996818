import java.util.Scanner;

public class DivisionExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        try {
            // Prompt user for two integers
            System.out.print("Enter first integer: ");
            int num1 = scanner.nextInt();
            
            System.out.print("Enter second integer: ");
            int num2 = scanner.nextInt();
            
            // Attempt to divide
            int result = num1 / num2;
            System.out.println("Result: " + num1 + " / " + num2 + " = " + result);
            
        } catch (ArithmeticException e) {
            // Catch division by zero
            System.out.println("Error: Cannot divide by zero! Please enter a non-zero second number.");
        } catch (Exception e) {
            // Catch other input errors
            System.out.println("Error: Invalid input! Please enter valid integers.");
        } finally {
            scanner.close();
        }
    }
}