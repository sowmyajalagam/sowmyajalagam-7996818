import java.util.Scanner;

// Custom exception class
class InvalidAgeException extends Exception {
    // Constructor with custom message
    public InvalidAgeException(String message) {
        super(message);
    }
}

// Main class to test the custom exception
public class AgeValidator {
    
    // Method to validate age
    public static void validateAge(int age) throws InvalidAgeException {
        if (age < 18) {
            throw new InvalidAgeException("Age " + age + " is invalid! User must be 18 years or older.");
        } else {
            System.out.println("Age " + age + " is valid. Access granted!");
        }
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        try {
            // Prompt user for age
            System.out.print("Enter your age: ");
            int age = scanner.nextInt();
            
            // Validate age
            validateAge(age);
            
        } catch (InvalidAgeException e) {
            // Catch custom exception and display message
            System.out.println("Custom Exception Caught: " + e.getMessage());
        } catch (Exception e) {
            // Handle invalid input (non-integer)
            System.out.println("Error: Please enter a valid numeric age.");
        } finally {
            scanner.close();
        }
        
        System.out.println("Program continues...");
    }
}
