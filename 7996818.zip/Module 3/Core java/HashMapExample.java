import java.util.HashMap;
import java.util.Scanner;

public class HashMapExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Create a HashMap with Integer keys and String values
        HashMap<Integer, String> studentMap = new HashMap<>();
        
        System.out.println("Student ID to Name Mapper");
        System.out.println("=========================");
        
        // Allow the user to add entries
        while (true) {
            System.out.print("\nEnter student ID (or -1 to finish adding): ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            if (id == -1) {
                break;
            }
            
            System.out.print("Enter student name: ");
            String name = scanner.nextLine();
            
            if (!name.trim().isEmpty()) {
                studentMap.put(id, name);
                System.out.println("Added: ID " + id + " -> " + name);
            } else {
                System.out.println("Name cannot be empty. Entry not added.");
            }
        }
        
        // Display all entries
        System.out.println("\n=========================");
        System.out.println("All Student Entries:");
        System.out.println("=========================");
        
        if (studentMap.isEmpty()) {
            System.out.println("No entries were added.");
        } else {
            for (Integer id : studentMap.keySet()) {
                System.out.println("ID: " + id + " | Name: " + studentMap.get(id));
            }
            System.out.println("\nTotal students: " + studentMap.size());
        }
        
        // Retrieve and display a name based on an entered ID
        System.out.println("\n=========================");
        System.out.println("Search Student by ID:");
        System.out.println("=========================");
        System.out.print("Enter student ID to search: ");
        int searchId = scanner.nextInt();
        
        String foundName = studentMap.get(searchId);
        
        if (foundName != null) {
            System.out.println("Student with ID " + searchId + ": " + foundName);
        } else {
            System.out.println("No student found with ID: " + searchId);
        }
        
        scanner.close();
    }
}