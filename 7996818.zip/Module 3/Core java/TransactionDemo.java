import java.sql.*;

public class TransactionDemo {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/testdb";
        String user = "root";
        String password = "root";

        try {
            Connection con = DriverManager.getConnection(url, user, password);

            // Disable auto commit
            con.setAutoCommit(false);

            PreparedStatement debit =
                    con.prepareStatement(
                    "UPDATE accounts SET balance = balance - ? WHERE id = ?");

            PreparedStatement credit =
                    con.prepareStatement(
                    "UPDATE accounts SET balance = balance + ? WHERE id = ?");

            // Debit Account 1
            debit.setInt(1, 1000);
            debit.setInt(2, 1);
            debit.executeUpdate();

            // Credit Account 2
            credit.setInt(1, 1000);
            credit.setInt(2, 2);
            credit.executeUpdate();

            // Commit transaction
            con.commit();

            System.out.println("Money transferred successfully!");

            con.close();

        } catch (Exception e) {
            System.out.println("Transaction failed. Rolling back...");

            e.printStackTrace();
        }
    }
}