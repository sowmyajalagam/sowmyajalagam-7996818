public class VirtualThreadsDemo {
    public static void main(String[] args) {

        for (int i = 1; i <= 100; i++) {
            int num = i;

            Thread.startVirtualThread(() -> {
                System.out.println("Virtual Thread " + num + " is running");
            });
        }

        System.out.println("All virtual threads started.");
    }
}