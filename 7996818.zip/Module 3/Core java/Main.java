// Interface definition
interface Playable {
    void play();
}

// Guitar class implementing Playable
class Guitar implements Playable {
    @Override
    public void play() {
        System.out.println("Strumming the guitar strings 🎸");
    }
}

// Piano class implementing Playable
class Piano implements Playable {
    @Override
    public void play() {
        System.out.println("Playing the piano keys 🎹");
    }
}

// Main class to test the implementation
public class Main {
    public static void main(String[] args) {
        // Instantiate the classes
        Guitar guitar = new Guitar();
        Piano piano = new Piano();
        
        // Call the play method
        System.out.println("Guitar: ");
        guitar.play();
        
        System.out.println("\nPiano: ");
        piano.play();
        
        // Using interface reference (polymorphism)
        System.out.println("\n--- Using interface references ---");
        Playable instrument1 = new Guitar();
        Playable instrument2 = new Piano();
        
        instrument1.play();
        instrument2.play();
    }
}
