import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Create an ArrayList to store names
        ArrayList<String> studentNames = new ArrayList<>();
        
        System.out.println("Student Name Manager");
        System.out.println("===================");
        
        // Allow the user to add names to the list
        while (true) {
            System.out.print("\nEnter a student name (or type 'done' to finish): ");
            String name = scanner.nextLine();
            
            if (name.equalsIgnoreCase("done")) {
                break;
            }
            
            if (!name.trim().isEmpty()) {
                studentNames.add(name);
                System.out.println("Added: " + name);
            } else {
                System.out.println("Name cannot be empty. Please try again.");
            }
        }
        
        // Display all names entered
        System.out.println("\n===================");
        System.out.println("All Student Names:");
        System.out.println("===================");
        
        if (studentNames.isEmpty()) {
            System.out.println("No names were entered.");
        } else {
            for (int i = 0; i < studentNames.size(); i++) {
                System.out.println((i + 1) + ". " + studentNames.get(i));
            }
            System.out.println("\nTotal students: " + studentNames.size());
        }
        
        scanner.close();
    }
}