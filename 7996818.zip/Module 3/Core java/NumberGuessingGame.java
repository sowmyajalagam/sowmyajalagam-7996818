import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        // Generate a random number between 1 and 100
        int secretNumber = random.nextInt(100) + 1;
        int guess = 0;
        int attempts = 0;
        
        System.out.println("Welcome to the Number Guessing Game!");
        System.out.println("I'm thinking of a number between 1 and 100.");
        System.out.println("Can you guess what it is?");
        
        // Continue until the user guesses correctly
        while (guess != secretNumber) {
            System.out.print("\nEnter your guess: ");
            guess = scanner.nextInt();
            attempts++;
            
            // Provide feedback
            if (guess < secretNumber) {
                System.out.println("Too low! Try again.");
            } else if (guess > secretNumber) {
                System.out.println("Too high! Try again.");
            } else {
                System.out.println("\nCongratulations! You guessed it!");
                System.out.println("The number was " + secretNumber);
                System.out.println("It took you " + attempts + " attempts.");
            }
        }
        
        scanner.close();
    }
}