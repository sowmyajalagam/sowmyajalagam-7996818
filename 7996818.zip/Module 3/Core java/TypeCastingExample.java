public class TypeCastingExample {
    public static void main(String[] args) {
        System.out.println("Type Casting Demonstration:");
        System.out.println();
        
        double doubleValue = 9.78;
        System.out.println("Original double value: " + doubleValue);
        
        int intFromDouble = (int) doubleValue;
        System.out.println("Double cast to int: " + intFromDouble);
        System.out.println("(Note: Decimal part .78 is truncated, not rounded)");
        System.out.println();
        
        int intValue = 42;
        System.out.println("Original int value: " + intValue);
        
        double doubleFromInt = intValue;
        System.out.println("Int cast to double: " + doubleFromInt);
        System.out.println("(Note: .0 is added automatically)");
        System.out.println();
   
        System.out.println("Bonus - Casting in expressions:");
        int a = 10, b = 3;
        double preciseResult = (double) a / b;
        System.out.println("(double) " + a + " / " + b + " = " + preciseResult);
        System.out.println("(Without casting: " + a + " / " + b + " = " + (a / b) + ")");
    }
}